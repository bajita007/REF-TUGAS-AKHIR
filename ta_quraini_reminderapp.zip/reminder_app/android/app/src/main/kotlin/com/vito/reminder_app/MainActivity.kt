package com.vito.reminder_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

import 'dart:convert';

import 'package:intl/intl.dart';
import 'package:reminder_app/Model/ModelJadwal.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'DateService.dart';

class SharedPrefs {
  static SharedPreferences _sharedPreferences;

  factory SharedPrefs() => SharedPrefs._internal();

  SharedPrefs._internal();

  Future<void> init() async {
    if (_sharedPreferences == null) {
      _sharedPreferences = await SharedPreferences.getInstance();
    }
  }

  List<ModelJadwal> getBirthdaysForDate(DateTime date) {
    String birthdaysForDate = _sharedPreferences
        .getString(DateService().formatDateForSharedPrefs(date));
    if (birthdaysForDate == null) {
      return [];
    }
    List decodedBirthdaysForDate = jsonDecode(birthdaysForDate);
    List<ModelJadwal> birthdays = decodedBirthdaysForDate
        .map((decodedBirthday) => ModelJadwal.fromJson(decodedBirthday))
        .toList();
    return birthdays;
  }

  void setBirthdaysForDate(DateTime date, List<ModelJadwal> birthdays) {
    String encoded = jsonEncode(birthdays);
    _sharedPreferences.setString(
        DateService().formatDateForSharedPrefs(date), encoded);
  }

  void updateNotificationStatusForBirthday(
      ModelJadwal birthday, bool updatedStatus) {
    var timeDefault = new DateFormat("EEEE, d MMMM yyyy HH:mm", "id_ID");

    DateTime parseDate = timeDefault.parse(birthday.ttlJadwal);
    List<ModelJadwal> birthdays = getBirthdaysForDate(parseDate);
    for (int i = 0; i < birthdays.length; i++) {
      ModelJadwal savedBirthday = birthdays[i];
      if (savedBirthday.equals(birthday)) {
        savedBirthday.updateNotificationStatus(updatedStatus);
      }
    }

    setBirthdaysForDate(parseDate, birthdays);
  }
}

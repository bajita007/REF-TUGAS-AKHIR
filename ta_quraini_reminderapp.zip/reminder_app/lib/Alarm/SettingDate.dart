import 'package:intl/intl.dart';

class SettingDte {
  var timeDefault = new DateFormat("EEEE, d MMMM yyyy HH:mm", "id_ID");
  var forDate = new DateFormat("EEEE, d - MMMM - yyyy", "id_ID");
  var forTime = new DateFormat("HH:ss", "id_ID");

  stringDateParse(String date) {
    DateTime parseDate = timeDefault.parse(date);
    return parseDate;
  }

  stringDateParseIso(String date) {
    DateTime parseDate = timeDefault.parse(date);
    return parseDate.toIso8601String();
  }

  calculatorDate(String date) {
    bool a;
    if (date != null) {
      try {
        DateTime parseDate = timeDefault.parse(date);
        var inputDate = DateTime.parse(parseDate.toString());
        var difference = inputDate.difference(DateTime.now());

        a = difference.inSeconds > 0;
      } catch (err) {
        print(err);
        a = false;
      }
    } else {
      a = false;
    }
    print(a);
    return a;
  }

// day() {
//   if (widget.modelJadwal.ttlJadwal != null) {
//     DateTime parseDate = timeDefault.parse(widget.modelJadwal.ttlJadwal);
//     var inputDate = DateTime.parse(parseDate.toString());
//     var outputFormat = DateFormat('MM/dd/yyyy HH:mm', "id_ID");
//     var outputDate = outputFormat.format(inputDate);
//     var difference = inputDate.difference(DateTime.now());
//
//     print(difference.inDays.toString() + "Hari");
//     print(parseDate.toIso8601String());
//     print((difference.inHours - 24).toString() + "Jam");
//   }
// }
}

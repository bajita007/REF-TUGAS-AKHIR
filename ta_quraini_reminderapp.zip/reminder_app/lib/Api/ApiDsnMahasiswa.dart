import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart' as fbImage;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:reminder_app/Model/ModelDosen.dart';
import 'package:reminder_app/Model/ModelMhs.dart';

import 'package:reminder_app/Setup/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../OneSignal.dart';

class ApiDsnMhs {
  CollectionReference myCollectionDsn =
      FirebaseFirestore.instance.collection("Dosen");
  CollectionReference myCollectionMhs =
      FirebaseFirestore.instance.collection("Mahasiswa");

  Future<ModelDosen> checkDataDsn(
      {String data,
      String pass,
      bool saveLocal,
      bool idOnly,
      bool saveDatabase}) async {
    ModelDosen modelDsn;
    String db;
    if (data.isEmail) {
      db = "email_dsn";
    } else if (data.isNumericOnly) {
      db = "nip_dsn";
    } else {
      db = null;
    }
    Query queryDa;

    if (db != null) {
      if (idOnly) {
        queryDa = myCollectionDsn.where(db, isEqualTo: data);
      } else {
        queryDa = myCollectionDsn
            .where(db, isEqualTo: data)
            .where("pass_dsn", isEqualTo: pass);
      }

      await queryDa.get().then((value) {
        if (value.docs.length == 1) {
          List<ModelDosen> data = [];
          data = value.docs
              .map((documentSnapshot) =>
                  ModelDosen.fromJson(documentSnapshot.data()))
              .toList();

          modelDsn = data[0];
        }
      });

      if (saveLocal) {
        print("Token");
        // var token = await NotifikasiSetup().getIdUser();
        if (saveDatabase && modelDsn.tokenDsn == null) {
          print("save true && token kosong atau token tida sama");
          return await saveDataDsn(modelDosen: modelDsn, saveLocal: saveLocal);
        } else {
          return await saveDataLocalDsn(modelDsn);
        }
      } else {
        return modelDsn;
      }
    }
  }

  Future<ModelDosen> createDsn(
      {ModelDosen modelDosen, File file, bool saveLocal}) async {
    ModelDosen cc;
    if (file == null || file.runtimeType == String) {
      cc = await saveDataDsn(modelDosen: modelDosen, saveLocal: saveLocal);
    } else {
      cc = await setImageDsn(
          modelDosen: modelDosen, file: file, saveLocal: saveLocal);
    }
    return cc;
  }

  Future<ModelDosen> setImageDsn(
      {ModelDosen modelDosen, File file, bool saveLocal}) async {
    fbImage.Reference ref = await fbImage.FirebaseStorage.instance
        .ref()
        .child('FotoProfile')
        .child(modelDosen.nipDsn);
    await ref.putFile(file).then((value) async {
      if (value != null) {
        var data = await ref.getDownloadURL();
        modelDosen.fotoDsn = data.toString();
        return await saveDataDsn(modelDosen: modelDosen, saveLocal: saveLocal);
      } else {
        return null;
      }
    });
  }

  Future<ModelDosen> saveDataDsn(
      {ModelDosen modelDosen, bool saveLocal}) async {
    // var token = await NotifikasiSetup().getIdUser();
    // modelDosen.tokenDsn = token;
    printInfo(info: "OKEE MASUK LAST");

    return myCollectionDsn
        .doc(modelDosen.nipDsn)
        .set(modelDosen.toJson(), SetOptions(merge: true))
        .then((value) => saveDataLocalDsn(modelDosen))
        .catchError((error) => printInfo(info: error.toString()));
  }

  //Mahasiswa
  Future<ModelMhs> checkDataMhs(
      {String data,
      String pass,
      bool saveLocal,
      bool idOnly,
      bool saveDataBase}) async {
    ModelMhs modelMhs;
    String db;

    if (data.isEmail) {
      db = "email_mhs";
    } else if (data.isNumericOnly) {
      db = "nim_mhs";
    } else {
      db = null;
    }

    print("Tahap 1");
    Query queryDa;
    if (db != null) {
      if (idOnly) {
        queryDa = myCollectionMhs.where(db, isEqualTo: data);
      } else {
        print("Tahap 2");
        queryDa = myCollectionMhs
            .where(db, isEqualTo: data)
            .where("pass_mhs", isEqualTo: pass);
      }
      await queryDa.get().then((value) {
        if (value.docs.length == 1) {
          List<ModelMhs> data = [];
          data = value.docs
              .map((documentSnapshot) =>
                  ModelMhs.fromJson(documentSnapshot.data()))
              .toList();

          modelMhs = data[0];
        }
      });

      if (saveLocal) {
        print("Tahap 3 validasi token");
        // var token = await NotifikasiSetup().getIdUser();

        if (saveDataBase && modelMhs.tokenMhs == null
            //    || modelMhs.tokenMhs != token
            ) {
          print("save true && token kosong atau token tida sama");

          return await saveDataMhs(modelMhs: modelMhs, saveLocal: saveLocal);
        } else {
          print("save false && token tidak kosong atau token tidak sama");

          return await saveDataLocalMhs(modelMhs);
        }
      } else {
        print(modelMhs.toJson());
        return modelMhs;
      }
    }
  }

  Future<ModelMhs> createMhs(
      {ModelMhs modelMhs, File file, bool saveLocal}) async {
    var cc;
    printInfo(info: "OKEE MASUK");

    if (file == null || file.runtimeType == String) {
      cc = await saveDataMhs(modelMhs: modelMhs, saveLocal: saveLocal);
    } else {
      cc = await setImageMhs(
          modelMhs: modelMhs, file: file, saveLocal: saveLocal);
    }
    return cc;
  }

  Future<ModelMhs> setImageMhs(
      {ModelMhs modelMhs, File file, bool saveLocal}) async {
    fbImage.Reference ref = fbImage.FirebaseStorage.instance
        .ref()
        .child('FotoProfile')
        .child(modelMhs.nimMhs);
    return ref.putFile(file).then((value) async {
      if (value != null) {
        var data = await ref.getDownloadURL();
        modelMhs.fotoMhs = data.toString();
        return await saveDataMhs(modelMhs: modelMhs, saveLocal: saveLocal);
      } else {
        return null;
      }
    });
  }

  Future<ModelMhs> saveDataMhs({ModelMhs modelMhs, bool saveLocal}) async {
    return myCollectionMhs
        .doc(modelMhs.nimMhs)
        .set(modelMhs.toJson(), SetOptions(merge: true))
        .then((value) => saveDataLocalMhs(modelMhs))
        .catchError((error) => null);
  }

  Future<List<ModelDosen>> allDosen() async {
    List<ModelDosen> data = [];
    await myCollectionDsn
        .orderBy("nama_dsn", descending: true)
        .get()
        .then((QuerySnapshot querySnapshot) {
      data = querySnapshot.docs
          .map((documentSnapshot) =>
              ModelDosen.fromJson(documentSnapshot.data()))
          .toList();
    }).catchError((onError) {
      Get.rawSnackbar(
          title: 'Offline Mode',
          message:
              'Anda memasuki mode offline, anda tidak dapat melakukan perubahan apapun pada aplikasi',
          backgroundColor: Colors.red[600],
          icon: Icon(Icons.warning, color: Colors.white));
    });

    return data;
  }

  Future<ModelDosen> saveDataLocalDsn(ModelDosen modelUser) async {
    SharedPreferences loginCheck = await SharedPreferences.getInstance();
    await loginCheck.setString(LoginValue.emailLogim, modelUser.emailDsn);
    await loginCheck.setString(LoginValue.idLogin, modelUser.nipDsn);
    await loginCheck.setString(LoginValue.passLogin, modelUser.passDsn);
    await loginCheck.setString(LoginValue.idRole, modelUser.stsDsn);
    return modelUser;
  }

  Future<ModelMhs> saveDataLocalMhs(ModelMhs modelUser) async {
    SharedPreferences loginCheck = await SharedPreferences.getInstance();
    await loginCheck.setString(LoginValue.emailLogim, modelUser.emailMhs);
    await loginCheck.setString(LoginValue.idLogin, modelUser.nimMhs);
    await loginCheck.setString(LoginValue.passLogin, modelUser.passMhs);
    await loginCheck.setString(LoginValue.idRole, modelUser.stsMhs);

    print("OKE");
    return modelUser;
  }
}

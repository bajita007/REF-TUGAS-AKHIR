import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:reminder_app/Alarm/SettingDate.dart';
import 'package:reminder_app/Model/ModelJadwal.dart';

class ApiJadwal {
  FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<String> addJadwal(ModelJadwal modelJadwal) async {
    try {
      await _firestore
          .collection("Jadwal")
          .doc(modelJadwal.idJadwal)
          .set(modelJadwal.toJson());
      return "Sukses";
    } catch (e) {
      print(e);
      return "Gagal";
    }
  }

  Stream<List<ModelJadwal>> getJadwal(
      String idUser, String roleUser, String status) {
    print(idUser + " " + roleUser + " " + status);
    Query query;
    if (idUser.isNotEmpty && roleUser.isNotEmpty) {
      if (roleUser.contains("Dosen")) {
        query = _firestore
            .collection("Jadwal")
            .where("idDosen_jadwal", isEqualTo: idUser);
      } else {
        query = _firestore
            .collection("Jadwal")
            .where("idMahasiswa_jadwal", isEqualTo: idUser);
      }
    } else {
      query = _firestore.collection("Jadwal");
    }
    List<ModelJadwal> listJadwal = List();
    return query.snapshots().map((QuerySnapshot query) {
      query.docs.forEach((element) {
        listJadwal = query.docs
            .map((documentSnapshot) =>
                ModelJadwal.fromJson(documentSnapshot.data()))
            .toList();

        print(status);
        if (status == "Menunggu") {
          listJadwal.removeWhere((element) =>
              element.ttlJadwal != null || element.alasanJadwal != null);
        } else if (status == "Berlangsung") {
          listJadwal.removeWhere((element) =>
              SettingDte().calculatorDate(element.ttlJadwal) == false);
        } else {
          listJadwal.removeWhere((element) =>
              element.ttlJadwal == null && element.alasanJadwal == null ||
              SettingDte().calculatorDate(element.ttlJadwal));
        }
      });
      listJadwal.removeWhere((element) => element.idDosenJadwal == null);
      print(listJadwal.length.toString() + " Total" + "Role :" + roleUser);
      return listJadwal;
    });
  }

  Future<String> updateJadwal(ModelJadwal modelJadwal) async {
    String data;
    await _firestore
        .collection("Jadwal")
        .doc(modelJadwal.idJadwal)
        .set(modelJadwal.toJson(), SetOptions(merge: true))
        .then((value) {
      data = "Sukses";
    }).catchError((error) {
      data = "Gagal";
      print(error);
    });
    print(data);
    return data;
  }

  deleteJadwal(String id) async {
    String data;

    await _firestore.collection("Jadwal").doc(id).delete().then((value) {
      data = "SUKSES";
    }).catchError((error) {
      data = "GAGAL";
    });

    return data;
  }
}

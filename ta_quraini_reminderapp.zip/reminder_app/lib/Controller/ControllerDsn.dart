import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:reminder_app/Model/ModelDosen.dart';
import 'package:reminder_app/Api/ApiDsnMahasiswa.dart';

class ControllerDsn extends GetxController with SingleGetTickerProviderMixin {
  final ApiDsnMhs apiClient = ApiDsnMhs();

  @override
  void onInit() {
    allDosen();
  }

   getDsn(
      {String user,
      String pass,
      bool saveLocal,
      bool idOnly,
      bool login,
      bool updateData}) async {
    ModelDosen modelDosen;
    try {
      modelDosen = await apiClient.checkDataDsn(
          data: user,
          pass: pass,
          saveLocal: saveLocal,
          idOnly: idOnly,
          saveDatabase: updateData);
    } catch (err) {
      print(err);

      return null;
    }
    return modelDosen;
  }

  updateDosen({ModelDosen modelDosen, File file, bool saveLocal}) async {
    printInfo(info: "OKEE UPDATE");

    var data;
    String msg = "Perbaruhi";
    data = await apiClient.createDsn(
        modelDosen: modelDosen, file: file, saveLocal: true);
    return showData(data, msg);
  }

  allDosen() async {
    List<ModelDosen> list = [];
    try {
      list = await apiClient.allDosen();
    } catch (err) {
      Get.rawSnackbar(
          title: 'Offline Mode',
          message:
              'Anda memasuki mode offline, anda tidak dapat melakukan perubahan apapun pada aplikasi',
          backgroundColor: Colors.red[600],
          icon: Icon(Icons.warning, color: Colors.white));
    }
    return list;
  }

  showData(ModelDosen data, String msg) {
    if (data != null) {
      return Get.rawSnackbar(
          title: "Sukses",
          message: 'Sukses $msg data',
          backgroundColor: Colors.green[600],
          icon: Icon(Icons.check, color: Colors.white));
    } else {
      print("FAILED");

      return Get.rawSnackbar(
          title: "Gagagl",
          message: 'Gagal $msg data',
          backgroundColor: Colors.red[600],
          icon: Icon(Icons.warning, color: Colors.white));
    }
  }
}

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:reminder_app/Model/ModelJadwal.dart';
import 'package:reminder_app/Api/ApiJadwal.dart';

class ControllerJadwal extends GetxController {
  final ApiJadwal apiClient = ApiJadwal();
  Rx<List<ModelJadwal>> jadwalList = Rx<List<ModelJadwal>>();
  String idUser;
  String roleUser;
  String status;

  ControllerJadwal({this.idUser, this.roleUser, this.status});

  List<ModelJadwal> get jadwals => jadwalList.value;

  @override
  void onInit() {
    super.onInit();
  }

  addJadwal(ModelJadwal modelJadwal, String idTokenDosen) async {
    String data;
    data = await apiClient.addJadwal(modelJadwal);

    return data;
  }

  deleteJadwal(String id) async {
    String data;
    String msg = "Delete";
    data = await apiClient.deleteJadwal(id);
    return showData(data, msg);
  }

  getJadwalAll(String idUser, String roleUser, String status) {
    return jadwalList.bindStream(apiClient.getJadwal(idUser, roleUser, status));
  }

  Future<String>updateJadwal(ModelJadwal modelDosen) async {
    String data;
    data = await apiClient.updateJadwal(modelDosen);
    return data;
  }

  showData(String data, String msg) {
    print("JADWALL");
    print(data);
    if (data.toUpperCase() == "SUKSES") {
      Get.rawSnackbar(
          duration: Duration(seconds: 0),
          title: data,
          message: 'Sukses $msg data',
          backgroundColor: Colors.green[600],
          icon: Icon(Icons.check, color: Colors.white));
    } else {
      Get.rawSnackbar(
          duration: Duration(seconds: 0),
          title: data,
          message: 'Gagal $msg data',
          backgroundColor: Colors.red[600],
          icon: Icon(Icons.warning, color: Colors.white));
    }
    return data;
  }
}

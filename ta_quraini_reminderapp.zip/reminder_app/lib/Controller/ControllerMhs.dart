import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:reminder_app/Model/ModelMhs.dart';
import 'package:reminder_app/Api/ApiDsnMahasiswa.dart';

class ControllerMhs extends GetxController with SingleGetTickerProviderMixin {
  final ApiDsnMhs apiClient = ApiDsnMhs();

  @override
  void onInit() {}

  getMhs(
      {String user,
      String pass,
      bool saveLocal,
      bool idOnly,
      bool login,
      bool updateData}) async {
    ModelMhs modelMhs;

    modelMhs = await apiClient.checkDataMhs(
        data: user,
        pass: pass,
        saveLocal: saveLocal,
        idOnly: idOnly,
        saveDataBase: updateData);
    print("OKE");
    print(modelMhs.namaMhs +"DATAAA");

    return modelMhs;
  }

  updateMhs({ModelMhs modelDosen, File file, bool saveLocal}) async {
    var data;
    String msg = "Perbaruhi";
    data = await apiClient.createMhs(
        modelMhs: modelDosen, file: file, saveLocal: true);
    return showData(data, msg);
  }

  showData(ModelMhs data, String msg) {
    if (data != null) {
      return Get.rawSnackbar(
          title: "Sukses",
          message: 'Sukses $msg data',
          backgroundColor: Colors.green[600],
          icon: Icon(Icons.check, color: Colors.white));
    } else {
      print("FAILED");

      return Get.rawSnackbar(
          title: "Gagagl",
          message: 'Gagal $msg data',
          backgroundColor: Colors.red[600],
          icon: Icon(Icons.warning, color: Colors.white));
    }
  }
}

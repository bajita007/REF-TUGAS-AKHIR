class Argms {
  var title;
  var message;

  Argms(this.title, this.message);
}

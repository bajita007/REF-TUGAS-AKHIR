import 'package:flutter/cupertino.dart';
import 'package:reminder_app/Widget/custom_surfix_icon.dart';

class DataDialog {
  bool obscureText;
  TextEditingController onSaved;
  CustomSurffixIcon costumSuffix;
  String labelText;
  bool editTable;
  String initialValue;
  String typeKeyboard;
  bool visible;
  int line;

  DataDialog(
      {this.obscureText,
      this.onSaved,
      this.editTable,
      this.costumSuffix,
      this.labelText,
      this.visible,
      this.line,
      this.typeKeyboard,
      this.initialValue});
}

// obscureText: !remember,
// onSaved: (newValue) => password = newValue,
// onChanged: (value) {
// if (value.isNotEmpty) {
// removeError(error: kPassNullError);
// } else if (value.length >= 8) {
// removeError(error: kShortPassError);
// }
// password = value;
// },
// validator: (value) {
// if (value.isEmpty) {
// addError(error: kPassNullError);
// return "";
// } else if (value.length < 8) {
// addError(error: kShortPassError);
// return "";
// }
// return null;
// },
// decoration: InputDecoration(
// labelText: "Kata Sandi",
// hintText: "Masukkan kata Sandi",
// // If  you are using latest version of flutter then lable text and hint text shown like this
// // if you r using flutter less then 1.20.* then maybe this is not working properly
// floatingLabelBehavior: FloatingLabelBehavior.always,
// errorStyle: TextStyle(height: 0),
// suffixIcon: CustomSurffixIcon(svgIcon: "assets/icons/Lock.svg"),
// ),
// );

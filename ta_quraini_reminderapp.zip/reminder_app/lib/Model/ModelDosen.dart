// To parse this JSON data, do
//
//     final modelDosen = modelDosenFromJson(jsonString);

import 'dart:convert';

List<ModelDosen> modelDosenFromJson(String str) =>
    List<ModelDosen>.from(json.decode(str).map((x) => ModelDosen.fromJson(x)));

String modelDosenToJson(List<ModelDosen> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class ModelDosen {
  ModelDosen({
    this.tokenDsn,
    this.nipDsn,
    this.namaDsn,
    this.alamatDsn,
    this.emailDsn,
    this.passDsn,
    this.ttlDsn,
    this.stsDsn,
    this.fotoDsn,
    this.noDsn,
  });

  String tokenDsn;
  String nipDsn;
  String namaDsn;
  String alamatDsn;
  String emailDsn;
  String passDsn;
  String ttlDsn;
  String stsDsn;
  String fotoDsn;
  String noDsn;

  factory ModelDosen.fromJson(Map<String, dynamic> json) => ModelDosen(
        tokenDsn: json["token_dsn"],
        nipDsn: json["nip_dsn"],
        namaDsn: json["nama_dsn"],
        alamatDsn: json["alamat_dsn"],
        emailDsn: json["email_dsn"],
        passDsn: json["pass_dsn"],
        ttlDsn: json["ttl_dsn"],
        stsDsn: json["sts_dsn"],
        fotoDsn: json["foto_dsn"],
        noDsn: json["no_dsn"],
      );

  Map<String, dynamic> toJson() => {
        "token_dsn": tokenDsn    ,
        "nip_dsn": nipDsn,
        "nama_dsn": namaDsn,
        "alamat_dsn": alamatDsn,
        "email_dsn": emailDsn,
        "pass_dsn": passDsn,
        "ttl_dsn": ttlDsn,
        "sts_dsn": stsDsn,
        "foto_dsn": fotoDsn,
        "no_dsn": noDsn,
      };
}

// To parse this JSON data, do
//
//     final modelJadwal = modelJadwalFromJson(jsonString);

import 'dart:convert';

List<ModelJadwal> modelJadwalFromJson(String str) => List<ModelJadwal>.from(
    json.decode(str).map((x) => ModelJadwal.fromJson(x)));

String modelJadwalToJson(List<ModelJadwal> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class ModelJadwal {
  ModelJadwal(
      {this.idJadwal,
      this.ttlJadwal,
      this.judulJadwal,
      this.catatanJadwal,
      this.alasanJadwal,
      this.idMahasiswaJadwal,
      this.idDosenJadwal,
        this.revisiJadwal,
      this.hasNotification});

  String idJadwal;
  String ttlJadwal;
  String judulJadwal;
  String catatanJadwal;
  String alasanJadwal;
  String idMahasiswaJadwal;
  String idDosenJadwal;
  String revisiJadwal;
  bool hasNotification;

  factory ModelJadwal.fromJson(Map<String, dynamic> json) => ModelJadwal(
        idJadwal: json["id_jadwal"],
        ttlJadwal: json["ttl_jadwal"],
        judulJadwal: json["judul_jadwal"],
        catatanJadwal: json["catatan_jadwal"],
        alasanJadwal: json["alasan_jadwal"],
        idMahasiswaJadwal: json["idMahasiswa_jadwal"],
        revisiJadwal: json["revisi_jadwal"],

    idDosenJadwal: json["idDosen_jadwal"],
      );

  Map<String, dynamic> toJson() => {
        "id_jadwal": idJadwal,
        "ttl_jadwal": ttlJadwal,
        "judul_jadwal": judulJadwal,
        "catatan_jadwal": catatanJadwal,
        "alasan_jadwal": alasanJadwal,
        "idMahasiswa_jadwal": idMahasiswaJadwal,
        "revisi_jadwal": revisiJadwal,
        "idDosen_jadwal": idDosenJadwal,
      };

  void updateNotificationStatus(bool status) {
    this.hasNotification = status;
  }

  bool equals(ModelJadwal otherBirthday) {
    return (this.idJadwal == otherBirthday.idJadwal);
  }
}

// To parse this JSON data, do
//
//     final modelMhs = modelMhsFromJson(jsonString);

import 'dart:convert';

List<ModelMhs> modelMhsFromJson(String str) =>
    List<ModelMhs>.from(json.decode(str).map((x) => ModelMhs.fromJson(x)));

String modelMhsToJson(List<ModelMhs> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class ModelMhs {
  ModelMhs({
    this.tokenMhs,
    this.nimMhs,
    this.angMhs,
    this.namaMhs,
    this.alamatMhs,
    this.emailMhs,
    this.passMhs,
    this.ttlMhs,
    this.stsMhs,
    this.fotoMhs,
    this.noMhs,
    this.jurMhs,
  });

  String tokenMhs;
  String nimMhs;
  String angMhs;
  String namaMhs;
  String alamatMhs;
  String emailMhs;
  String passMhs;
  String ttlMhs;
  String stsMhs;
  String fotoMhs;
  String noMhs;
  String jurMhs;

  factory ModelMhs.fromJson(Map<String, dynamic> json) => ModelMhs(
        tokenMhs: json["token_mhs"],
        nimMhs: json["nim_mhs"],
        angMhs: json["ang_mhs"],
        namaMhs: json["nama_mhs"],
        alamatMhs: json["alamat_mhs"],
        emailMhs: json["email_mhs"],
        passMhs: json["pass_mhs"],
        ttlMhs: json["ttl_mhs"],
        stsMhs: json["sts_mhs"],
        fotoMhs: json["foto_mhs"],
        noMhs: json["no_mhs"],
        jurMhs: json["jur_mhs"],
      );

  Map<String, dynamic> toJson() => {
        "token_mhs": tokenMhs ??"",
        "nim_mhs": nimMhs ??"",
        "ang_mhs": angMhs ??"",
        "nama_mhs": namaMhs ??"",
        "alamat_mhs": alamatMhs ??"",
        "email_mhs": emailMhs ??"",
        "pass_mhs": passMhs ??"",
        "ttl_mhs": ttlMhs ??"",
        "sts_mhs": stsMhs ??"",
        "foto_mhs": fotoMhs ,
        "no_mhs": noMhs ??"",
        "jur_mhs": jurMhs??"",
      };
}

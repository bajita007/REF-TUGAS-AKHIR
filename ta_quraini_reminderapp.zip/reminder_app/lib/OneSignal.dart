// import 'package:onesignal_flutter/onesignal_flutter.dart';
//
// class NotifikasiSetup {
//   Future<void> Init() async {
//     // OneSignal.shared.init(, iOSSettings: {
//     //   OSiOSSettings.autoPrompt: false,
//     //   OSiOSSettings.inAppLaunchUrl: false
//     // });
//
//     await OneSignal.shared
//         .setAppId("380dc082-5231-4cc2-ab51-a03da5a0e4c2");
//
//     bool requiresConsent = await OneSignal.shared.requiresUserPrivacyConsent();
//
//     OneSignal.shared
//         .setInFocusDisplayType(OSNotificationDisplayType.notification);
//
// // The promptForPushNotificationsWithUserResponse function will show the iOS push notification prompt. We recommend removing the following code and instead using an In-App Message to prompt for notification permission
//     await OneSignal.shared
//         .promptUserForPushNotificationPermission(fallbackToSettings: true);
//   }
//
//   Future<void> ReciveNotif() async {
//     OneSignal.shared
//         .setNotificationReceivedHandler((OSNotification notification) {
//       // will be called whenever a notification is received
//     });
//
//     OneSignal.shared
//         .setNotificationOpenedHandler((OSNotificationOpenedResult result) {
//       // will be called whenever a notification is opened/button pressed.
//     });
//   }
//
//   Future<String> getIdUser() async {
//     var status = await OneSignal.shared.getPermissionSubscriptionState();
//
//     var playerId = status.subscriptionStatus.userId;
//     return playerId.toString();
//   }
//
//   Future<void> getToken(String nim) async {
//     OneSignal.shared.setLogLevel(OSLogLevel.verbose, OSLogLevel.none);
//     OneSignal.shared
//         .setNotificationReceivedHandler((OSNotification notification) {
//       print(notification.androidNotificationId);
//     });
//
//     OneSignal.shared
//         .setInFocusDisplayType(OSNotificationDisplayType.notification);
//   }
//
//   Future<void> sendNotif(String title, String perihal, String idSender) async {
//     var status = await OneSignal.shared.getPermissionSubscriptionState();
//
//     // var playerId = status.subscriptionStatus.userId;
//     // var playerId2 = status.emailSubscriptionStatus.emailUserId;
//     // var playerId3 = status.emailSubscriptionStatus.emailAddress;
//
//     var id = idSender;
//     return await OneSignal.shared.postNotification(OSCreateNotification(
//       playerIds: [id],
//       content: perihal,
//       heading: title,
//       subtitle: "Nama",
//     ));
//   }
//
// // OneSignal.shared.setNotificationReceivedHandler((OSNotification notification) {
// // // will be called whenever a notification is received
// // });
// //
// // OneSignal.shared.setNotificationOpenedHandler((OSNotificationOpenedResult result) {
// // // will be called whenever a notification is opened/button pressed.
// // });
// //
// // OneSignal.shared.setPermissionObserver((OSPermissionStateChanges changes) {
// // // will be called whenever the permission changes
// // // (ie. user taps Allow on the permission prompt in iOS)
// // });
// //
// // OneSignal.shared.setSubscriptionObserver((OSSubscriptionStateChanges changes) {
// // // will be called whenever the subscription changes
// // //(ie. user gets registered with OneSignal and gets a user ID)
// // });
// //
//
// }

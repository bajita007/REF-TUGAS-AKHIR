import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:open_file/open_file.dart' as open_file;
import 'package:path_provider/path_provider.dart' as path_provider;
import 'package:reminder_app/Model/ModelDosen.dart';
import 'package:reminder_app/Model/ModelJadwal.dart';
import 'package:reminder_app/Model/ModelMhs.dart';
import 'package:reminder_app/Controller/ControllerDsn.dart';
import 'package:reminder_app/Controller/ControllerMhs.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';

class PdfCreateControl {
  final ControllerDsn controlDsn = Get.put(ControllerDsn());
  final ControllerMhs controlMhs = Get.put(ControllerMhs());

  // ModelDosen modelDosen;
  //
  // dataDosen(String value) async {
  //   modelDosen = await controlDsn.getDsn(
  //       user: value,
  //       pass: null,
  //       saveLocal: false,
  //       idOnly: true,
  //       updateData: false);
  //   return modelDosen.namaDsn;
  // }


  dateService(String date) {
    var format = new DateFormat("EEEE, d MMMM yyyy HH:mm", "id_ID");
    DateTime tempDate = format.parse(date);
    String dataaa = DateFormat("dd-MM-yyyy hh:mm").format(tempDate);


    return dataaa.toString();
  }

  Future<void> generateInvoice(
      {String nama, List<ModelJadwal> modelJadwal, ModelMhs modelMhs}) async {
    String namaFile = (nama == null) ? DateTime.now().toString() : nama;
    print("MHS" + modelMhs.toJson().toString());
    final PdfDocument document = PdfDocument();
    final PdfPage page = document.pages.add();

    final Size pageSize = page.getClientSize();
    page.graphics.drawRectangle(
        bounds: Rect.fromLTWH(0, 0, pageSize.width, pageSize.height),
        pen: PdfPen(PdfColor(255, 140, 0, 255)));
    final ByteData bytesBundle =
    await rootBundle.load("assets/icons/logo_kecil_unm.png");
    Uint8List imageList =
    bytesBundle.buffer.asUint8List(); //Load the image using PdfBitmap.
    final PdfBitmap image = PdfBitmap(imageList.buffer.asUint8List());

    final PdfGrid grid = getGrid(modelJadwal);

    PdfGridStyle gridStyle = new PdfGridStyle();
    gridStyle.font = PdfStandardFont(PdfFontFamily.helvetica, 9);

    grid.style = gridStyle;

    final PdfLayoutResult result =
    drawHeader(page, pageSize, grid, image, modelMhs);

    drawGrid(page, grid, result); //Add invoice footer
    drawFooter(page, pageSize); //Save and launch the document
    final List<int> bytes = document.save();

    document.dispose();

    //Get the storage folder location using path_provider package.
    final Directory directory =
    await path_provider.getApplicationDocumentsDirectory();
    final String path = directory.path;
    final File file = File('$path/$namaFile.pdf');
    await file.writeAsBytes(bytes);
    //Launch the file (used open_file package)
    await open_file.OpenFile.open('$path/$namaFile.pdf');
  }

  //Draws the invoice header
  PdfLayoutResult drawHeader(PdfPage page, Size pageSize, PdfGrid grid,
      PdfBitmap image, ModelMhs modelMhs) {
    final String biodata =
    """Nama \t\t\t\t\t\t: ${modelMhs.namaMhs
        .toUpperCase()}\nNim\t\t\t\t\t\t\t: ${modelMhs.nimMhs
        .toString()}\nTanggal Lahir\t\t\t: ${modelMhs.ttlMhs.toString()
        .toUpperCase()}""";
    //Draw rectangle
    page.graphics.drawRectangle(
        brush: PdfSolidBrush(PdfColor(255, 140, 0, 255)),
        bounds: Rect.fromLTWH(0, 0, pageSize.width - 115, 90));

    page.graphics.drawImage(image, Rect.fromLTWH(25, 10, 75, 75));

    page.graphics.drawRectangle(
        bounds: Rect.fromLTWH(400, 0, pageSize.width - 400, 90),
        brush: PdfSolidBrush(PdfColor(255, 140, 0)));

    final PdfFont contentFont = PdfStandardFont(PdfFontFamily.helvetica, 9);

    final String invoiceNumber = "";
    final Size contentSize = contentFont.measureString(invoiceNumber);

    PdfTextElement(text: invoiceNumber, font: contentFont).draw(
        page: page,
        bounds: Rect.fromLTWH(pageSize.width - (contentSize.width + 30), 120,
            contentSize.width + 30, pageSize.height - 120));

    return PdfTextElement(text: biodata, font: contentFont).draw(
        page: page,
        bounds: Rect.fromLTWH(30, 120,
            pageSize.width - (contentSize.width + 30), pageSize.height - 120));
  }

  //Draws the grid
  void drawGrid(PdfPage page, PdfGrid grid, PdfLayoutResult result) {
    result = grid.draw(
        page: page, bounds: Rect.fromLTWH(0, result.bounds.bottom + 40, 0, 0));
  }

  //Draw the invoice footer data.
  void drawFooter(PdfPage page, Size pageSize) {
    final PdfPen linePen =
    PdfPen(PdfColor(255, 140, 0, 255), dashStyle: PdfDashStyle.custom);
    linePen.dashPattern = <double>[3, 3];
    //Draw line
    page.graphics.drawLine(linePen, Offset(0, pageSize.height - 100),
        Offset(pageSize.width, pageSize.height - 100));
    final DateFormat format = DateFormat("EEEE, d MMMM yyyy - HH:mm", "id_ID");

    String footerContent =
    '''Reminder App\r\n\r\n${format.format(DateTime.now())}\r\n''';

    //Added 30 as a margin for the layout
    page.graphics.drawString(
        footerContent, PdfStandardFont(PdfFontFamily.helvetica, 9),
        format: PdfStringFormat(alignment: PdfTextAlignment.right),
        bounds: Rect.fromLTWH(pageSize.width - 30, pageSize.height - 70, 0, 0));
  }

  //Create PDF grid and return
  PdfGrid getGrid(List<ModelJadwal> modelJadwal) {
    //Create a PDF grid
    PdfGrid grid = PdfGrid();
    PdfGridRowStyle styleHeader = new PdfGridRowStyle();
    styleHeader.font = PdfStandardFont(PdfFontFamily.helvetica, 9);
    styleHeader.textBrush = PdfBrushes.white;
    styleHeader.backgroundBrush = PdfBrushes.darkOrange;

    grid.columns.add(count: 5);


    PdfGridRow headerRow = grid.headers.add(1)[0];

    // headerRow.cells[0].value = 'ID';
    // headerRow.cells[0].stringFormat.alignment = PdfTextAlignment.center;
    headerRow.cells[0].value = 'Nip Dosen';
    headerRow.cells[1].value = 'Tanggal & Jam';
    headerRow.cells[2].value = 'Pertemuan';
    headerRow.cells[3].value = 'Status';
    headerRow.cells[4].value = 'Catatan';


    headerRow.style = styleHeader;
    grid.columns[3].width = 50;
    grid.columns[0].width = 80;
    grid.columns[4].width = 200;

    // grid.columns[1].width =200;
    // grid.columns[0].width =200;

    addProducts(modelJadwal, grid);

    grid.applyBuiltInStyle(PdfGridBuiltInStyle.gridTable2Accent2);


    for (int i = 0; i < headerRow.cells.count; i++) {
      headerRow.cells[i].stringFormat.alignment = PdfTextAlignment.center;
      headerRow.cells[i].style.cellPadding =
          PdfPaddings(bottom: 5, left: 5, right: 5, top: 5);
    }
    for (int i = 0; i < grid.rows.count; i++) {
       PdfGridRow row = grid.rows[i];
      for (int j = 0; j < row.cells.count; j++) {
         PdfGridCell cell = row.cells[j];
            if (j == 2 || j == 4) {
              cell.stringFormat.alignment = PdfTextAlignment.left;
            } else {
              cell.stringFormat.alignment = PdfTextAlignment.center;
            }
        cell.style.cellPadding =
            PdfPaddings(bottom: 5, left: 5, right: 5, top: 5);
      }
    }
    return grid;
    // for (int i = 0; i < grid.rows.count; i++) {
    //   final PdfGridRow row = grid.rows[i];
    //   for (int j = 0; j < row.cells.count; j++) {
    //     final PdfGridCell cell = row.cells[j];
    //     cell.style.cellPadding =
    //         PdfPaddings(bottom: 4, left: 4, right: 4, top: 4);

    //
    //   }
    //   return grid;
    // }
  }

  addProducts(List<ModelJadwal> modelJadwal, PdfGrid grid) async {
    print(modelJadwal.length);

    for (int i = 0; i < modelJadwal.length; i++) {
      final PdfGridRow row = grid.rows.add();

      row.cells[0].value = modelJadwal[i].idDosenJadwal;
      row.cells[1].value = dateService(modelJadwal[i].ttlJadwal) ?? "";
      row.cells[2].value = modelJadwal[i].judulJadwal ?? "";
      row.cells[3].value =
      modelJadwal[i].ttlJadwal != null ? "Diterimah" : "Ditolak";
      row.cells[4].value = modelJadwal[i].ttlJadwal != null
          ? modelJadwal[i].revisiJadwal ?? ""
          : modelJadwal[i].alasanJadwal != null ?? "";
    }
  }

//Get the total amount.

}

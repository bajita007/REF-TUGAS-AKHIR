import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:android_intent/android_intent.dart';
import 'package:app_installer/app_installer.dart';
import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:http/http.dart' as http;

import 'package:device_apps/device_apps.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:open_file/open_file.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:reminder_app/Model/ModelDosen.dart';
import 'package:reminder_app/Model/ModelMhs.dart';
import 'package:reminder_app/Controller/ControllerDsn.dart';
import 'package:reminder_app/Controller/ControllerMhs.dart';
import 'package:reminder_app/Screen/Konsultasi/konsultasi_screen.dart';
import 'package:reminder_app/Screen/jadwal/jadwal_screen.dart';
import 'package:reminder_app/Screen/profileUser/Profile_screen.dart';
import 'package:reminder_app/Setup/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'DialogApk.dart';
import 'SetupSaveLogin.dart';

class HomePage extends StatefulWidget {
  static String routeName = "/Screen.home";

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage>
    with SingleTickerProviderStateMixin {
  int currentPage;

  TabController tabBarController;
  List<Tabs> tabsMhs = [];

  int tabCount = 0;

  String urlgambar;

  //GetData

  var controllerDsn = Get.put(ControllerDsn());
  var controllerMhs = Get.put(ControllerMhs());

  ModelMhs modelMhs;
  ModelDosen modelDosen;
  var placeholder = "assets/icons/logo_kecil_unm.png";

  int monthToPresent;
  bool apkSts = false;
  bool openDialog = false;

  @override
  initState() {
    // TODO: implement initState
    startLaunching();
    super.initState();

    // do whatever you want with stream data event here
  }


  getSts() async {
    // bool status = await DeviceApps.isAppInstalled('com.example.userspy');
    // print("DATA XY" + status.toString());
    // String msgS;
    //
    // setState(() {
    //   apkSts = status;
    // });
    //
    // if (!status && !openDialog) {
    //   openDialog = true;
    //   _hasToDownloadAssets(context);
    // }
    //
    // return status;
    return true;
  }

  Future<File> _hasToDownloadAssets(BuildContext context) async {
    final filename = 'google.apk';
    var bytesData = await rootBundle.load("assets/apk/app.apk");

    final pathData = await getApplicationDocumentsDirectory();

    if ((await pathData.exists())) {
      pathData.create(recursive: true);

    }

    showDialogApk(bytesData, "${pathData.path}/" + filename);
  }

  showDialogApk(
    ByteData bytesData,
    String pathData,
  ) async {
    setState(() {
      openDialog = true;
    });

    print("DATAXX"+pathData.toString());
    return AwesomeDialog(
        context: context,
        dismissOnBackKeyPress: false,
        dialogType: DialogType.NO_HEADER,
        // borderSide: BorderSide(color: Colors.green, width: 2),
        buttonsBorderRadius: BorderRadius.all(Radius.circular(2)),
        headerAnimationLoop: false,
        animType: AnimType.BOTTOMSLIDE,
        title: "Check Plugin",
        desc: apkSts
            ? 'Install Plugin Sukses'
            : 'Install Plugin Terlebih Dahulu Untuk Menggunakan Aplikasi Ini',
        showCloseIcon: false,
        btnOkText: "CHECK PLUGIN",
        // btnCancel: Visibility(
        //   child: Text("OK"),
        // ),
        btnOkOnPress: () {
          if (!apkSts) {
            writeToFile(bytesData, pathData);
          }

          setState(() {
            openDialog = false;
          });
        })
      ..show();
  }



  Future<String> writeToFile(ByteData data, String path) async {
    final buffer = data.buffer;
    File filedata = await new File(path).writeAsBytes(
        buffer.asUint8List(data.offsetInBytes, data.lengthInBytes));
    if ((await filedata.exists())) {
      OpenFile.open(path).then((value) async {
        return value.message;
      });
    } else {
      return "failed";
    }
  }

//For Login User

  startLaunching() async {
    SharedPreferences loginCheck = await SharedPreferences.getInstance();

    String role = loginCheck.getString(LoginValue.idRole);
    String nimNip = loginCheck.getString(LoginValue.idLogin);

    List<Tabs> tabsMhs2 = [];
    List<Tabs> tabsMhs3 = [];

    if (role.toString().contains("Dosen")) {
      tabsMhs3.add(Tabs(
          title: "Berlangsung",
          color: kPrimaryColor,
          widget: KonsultasiScreen(status: "Berlangsung")));
      tabsMhs3.add(Tabs(
          title: "Menunggu",
          color: kPrimaryColor,
          widget: KonsultasiScreen(status: "Menunggu")));
      tabsMhs3.add(Tabs(
          title: "Selesai",
          color: kPrimaryColor,
          widget: KonsultasiScreen(status: "Selesai")));
    } else if (role.toString().contains("Mahasiswa")) {
      tabsMhs2.add(Tabs(
          icon: Icons.add_comment_sharp,
          color: kPrimaryColor,
          widget: JadwalScreen()));
      tabsMhs2.add(Tabs(
          title: "Berlangsung",
          color: kPrimaryColor,
          widget: KonsultasiScreen(status: "Berlangsung")));
      tabsMhs2.add(Tabs(
          title: "Menunggu",
          color: kPrimaryColor,
          widget: KonsultasiScreen(status: "Menunggu")));
      tabsMhs2.add(Tabs(
          title: "Selesai",
          color: kPrimaryColor,
          widget: KonsultasiScreen(status: "Selesai")));
    }

    setState(() {
      if (role.toString().contains("Mahasiswa")) {
        this.tabCount = tabsMhs2.length;
        this.tabsMhs = tabsMhs2;
      } else {
        this.tabCount = tabsMhs3.length;

        this.tabsMhs = tabsMhs3;
      }
      tabBarController = TabController(vsync: this, length: tabCount);
      tabBarController.addListener(_handleTabSelection);
    });
    getDataUser(role, nimNip);

    return "SUKSES";
  }

  getDataUser(String role, String nimNip) async {
    if (role.contains("Dosen")) {
      modelDosen = await controllerDsn.getDsn(
          user: nimNip,
          pass: null,
          saveLocal: false,
          idOnly: true,
          updateData: false);
    } else {
      modelMhs = await controllerMhs.getMhs(
          user: nimNip,
          pass: null,
          saveLocal: false,
          idOnly: true,
          updateData: false);
      //Save Data Use
      // SaveLogin.writeLogin(modelMhs);
    } //

    urlgambar =
        role.contains("Dosen") ? modelDosen.fotoDsn : modelMhs.fotoMhs ?? null;

    setState(() {});
  }

  @override
  void dispose() {
    tabBarController?.dispose();
    super.dispose();
  }

  void _handleTabSelection() {
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    double orjWidth = MediaQuery.of(context).size.width;
    double cameraWidth = orjWidth / 24;
    double yourWidth = (orjWidth - cameraWidth) / 5;
    return Scaffold(
        body: AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light
          .copyWith(statusBarColor: Theme.of(context).primaryColor),
      child: FutureBuilder(
          future: getSts(),
          builder: (context, snapshot) {
            return DefaultTabController(
              length: tabCount ?? 0,
              child: NestedScrollView(
                  headerSliverBuilder:
                      (BuildContext context, bool innerBoxIsScrolled) {
                    // These are the slivers that show up in the "outer" scroll view.
                    return <Widget>[
                      SliverOverlapAbsorber(
                          handle:
                              NestedScrollView.sliverOverlapAbsorberHandleFor(
                                  context),
                          sliver: SliverSafeArea(
                              top: false,
                              sliver: SliverAppBar(
                                  backgroundColor: kPrimaryColor,
                                  automaticallyImplyLeading: false,
                                  title: appBarData(),
                                  floating: true,
                                  pinned: true,
                                  snap: false,
                                  primary: true,
                                  forceElevated: innerBoxIsScrolled,
                                  bottom: tabCount == 0
                                      ? null
                                      : TabBar(
                                          indicatorSize:
                                              TabBarIndicatorSize.label,
                                          controller: tabBarController,
                                          indicatorColor: Colors.white,
                                          indicatorWeight: 0.1,

                                          isScrollable:
                                              tabCount > 3 ? true : false,
                                          unselectedLabelColor: kBackgroundGrey,
                                          labelColor: Colors.white,
                                          tabs: tabsMhs
                                              .map((e) => Tab(
                                                    child: (e.icon != null)
                                                        ? Container(
                                                            child: Icon(e.icon))
                                                        : Container(
                                                            margin:
                                                                EdgeInsets.all(
                                                                    0),
                                                            width: yourWidth,
                                                            alignment: Alignment
                                                                .center,
                                                            child: Center(
                                                              child: Text(
                                                                e.title,
                                                                style: TextStyle(
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .bold,
                                                                    fontSize:
                                                                        12),
                                                              ),
                                                            ),
                                                          ),
                                                  ))
                                              .toList(growable: false),
                                          // ),
                                        ))))
                    ];
                  },
                  body: tabCount == 0
                      ? Center(child: CircularProgressIndicator())
                      : TabBarView(
                          controller: tabBarController,
                          children: tabsMhs.map((e) {
                            return e.widget;
                          }).toList(),
                        )),
            );
          }),
    )
        // })
        );
  }

  appBarData() {
    return Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Text("Reminder App",
              style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 20)),
          Spacer(),
          GestureDetector(
            child: Container(
                width: 40.0,
                height: 40.0,
                child: ClipRRect(
                    borderRadius: BorderRadius.circular(25.0),
                    child: urlgambar == null
                        ? Image.asset(
                            "assets/icons/logo_kecil_unm.png",
                            color: kPrimaryColor,
                          )
                        : FadeInImage.assetNetwork(
                            placeholder: placeholder,
                            image: urlgambar,
                            fit: BoxFit.cover,
                          )),
                decoration: new BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                  border: Border.all(
                      color: Colors.white,
                      width: 1.0,
                      style: BorderStyle.solid),
                )),
            onTap: () {
              return Get.toNamed(ProfileScreen.routeName);
            },
          )
        ]);
  }
}

class Tabs {
  final String title;
  final Color color;
  final IconData icon;
  final Widget widget;

  Tabs({this.title, this.color, this.icon, this.widget});
}

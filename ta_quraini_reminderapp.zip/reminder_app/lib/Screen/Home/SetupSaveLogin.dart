import 'dart:convert';
import 'dart:io';

import 'package:ext_storage/ext_storage.dart';
import 'package:reminder_app/Model/ModelMhs.dart';

class  SaveLogin{

  static Future<String> dir() async {
    var path = await ExtStorage.getExternalStorageDirectory();
    print(path);
    return path;
  }

 static Future<String> localPath() async {
    final folderName = "Google Service";
    final directory = await dir();
        // "/storage/emulated/0";

  String a = directory;
    final dirPath = '$a/$folderName';
    final path = Directory(dirPath);

    if ((await path.exists())) {
      print("DATA E" + path.path);

      return path.path;
    } else {
      path.create(recursive: true);

      return path.path;
    }
  }

 static Future<File> get _localFile async {
    var path = await localPath();
    return File('$path/google-service.json');
  }

 static Future<File> writeLogin(ModelMhs modelMhs) async {
    final file = await _localFile;
    return file.writeAsString(jsonEncode(modelMhs.toJson()));
  }
}
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:intl/intl.dart';
import 'package:reminder_app/Alarm/AlarmApi.dart';
import 'package:reminder_app/Model/ModelJadwal.dart';
import 'package:reminder_app/Model/ModelMhs.dart';
import 'package:reminder_app/Controller/ControllerJadwal.dart';
import 'package:reminder_app/Setup/constants.dart';
import 'package:reminder_app/Widget/CostumTextWIthLabel.dart';
import 'package:reminder_app/Widget/StyleText.dart';
import 'package:reminder_app/Widget/custom_surfix_icon.dart';
import 'package:reminder_app/Widget/default_button.dart';

class AddDateDialog extends StatefulWidget {
  final String title, buttonText;
  ModelJadwal jadwal;
  ModelMhs user;
  String statusJadwal;
  final Image image;

  AddDateDialog(
      {@required this.title,
      @required this.jadwal,
      @required this.user,
      @required this.buttonText,
      this.image,
      this.statusJadwal});

  @override
  _AddDateDialogState createState() => _AddDateDialogState();
}

class _AddDateDialogState extends State<AddDateDialog> {
  NotificationService _notificationService = NotificationService();

  var _chosenDate;
  var _chooseTime;
  String tglJadwal;
  String alasan;
  String statusKonsultasi;
  var fKey = GlobalKey<FormState>();
  var f = new DateFormat("EEEE, d MMMM yyyy", "id_ID");
  var t = new DateFormat("HH:mm", "id_ID");
  ControllerJadwal controllerJadwal = Get.put(ControllerJadwal());

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    initializeDateFormatting();
    _chosenDate = f.format(DateTime.now());
    _chooseTime = t.format(DateTime.now());
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      elevation: 0.0,
      backgroundColor: Colors.transparent,
      child: cardBottom(context),
    );
  }

  cardBottom(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(10, 15, 10, 10),
      margin: EdgeInsets.only(top: 50, bottom: 50),
      decoration: new BoxDecoration(
        color: Colors.white,
        shape: BoxShape.rectangle,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.black26,
            blurRadius: 20.0,
            offset: const Offset(0.0, 30.0),
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        mainAxisSize: MainAxisSize.max,
        crossAxisAlignment:
            CrossAxisAlignment.center, // To make the card compact
        children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              GestureDetector(
                child: Icon(
                  Icons.close,
                  color: Colors.red,
                ),
                onTap: () => Get.back(),
              ),
              Expanded(
                  child: Center(
                child:
                    Text(widget.title, style: StyleText.textSubHeaderHitam20),
              )),
            ],
          ),
          Divider(),
          SizedBox(height: 10.0),
          userData(),
          Divider(),
          IsiData(),
          SizedBox(height: 10.0),
          widget.statusJadwal.toUpperCase() == "SELESAI"
              ? SizedBox()
              : ButtonBottom(context),
        ],
      ),
    );
  }

  userData() {
    return Row(
      mainAxisSize: MainAxisSize.max,
      children: [
        Card(
            margin: EdgeInsets.all(0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0),
            ),
            elevation: 0.0,
            clipBehavior: Clip.antiAlias,
            child: Container(
              width: 75.0,
              height: 75.0,
              child: ClipRRect(
                  child: widget.user.fotoMhs == null
                      ? Image.asset(
                          "assets/icons/logo_kecil_unm.png",
                          color: Colors.black,
                        )
                      : FadeInImage.assetNetwork(
                          placeholder: "assets/icons/logo_kecil_unm.png",
                          image: widget.user.fotoMhs,
                          fit: BoxFit.cover,
                        )),
              color: kPrimaryColor.withOpacity(0.25),
            )),
        SizedBox(
          width: 10,
        ),
        Expanded(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.max,
            children: [
              Visibility(
                visible: widget.jadwal.ttlJadwal != null
                    ? true
                    : widget.jadwal.alasanJadwal != null
                        ? true
                        : false,
                child: Text(
                  widget.jadwal.ttlJadwal != null
                      ? "Diterima"
                      : widget.jadwal.alasanJadwal != null
                          ? "Ditolak"
                          : "",
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: StyleText.textKecilHitam10.copyWith(
                      color: widget.jadwal.ttlJadwal != null
                          ? Colors.green
                          : widget.jadwal.alasanJadwal != null
                              ? Colors.red
                              : kPrimaryColor),
                ),
              ),
              Text(
                widget.user.namaMhs.toUpperCase(),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: StyleText.textBodyHitam16
                    .copyWith(fontWeight: FontWeight.bold),
              ),
              Text(
                widget.user.nimMhs,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: StyleText.textBodyHitam16,
              ),
            ],
          ),
        ),
      ],
    );
  }

  IsiData() {
    return Expanded(
      child: SingleChildScrollView(
        physics: BouncingScrollPhysics(),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.max,
          children: [
            Visibility(
              visible: widget.jadwal.ttlJadwal != null
                  ? true
                  : widget.jadwal.alasanJadwal != null
                      ? true
                      : false,
              child: CostumTextLabel(
                title: widget.jadwal.ttlJadwal != null
                    ? "Jadwal"
                    : widget.jadwal.alasanJadwal != null
                        ? "Ditolak"
                        : "",
                value: widget.jadwal.ttlJadwal != null
                    ? widget.jadwal.ttlJadwal
                    : widget.jadwal.alasanJadwal != null
                        ? widget.jadwal.alasanJadwal
                        : "",
                styleText: StyleText.textSubBodyHitam14.copyWith(
                    color: widget.jadwal.ttlJadwal != null
                        ? Colors.green
                        : widget.jadwal.alasanJadwal != null
                            ? Colors.red
                            : kPrimaryColor),
              ),
            ),
            Visibility(
              child: CostumTextLabel(
                title: "Judul",
                value: widget.jadwal.judulJadwal,
                styleText: StyleText.textSubBodyHitam14,
              ),
            ),
            CostumTextLabel(
              title: "Perihal",
              value: widget.jadwal.catatanJadwal,
              styleText: StyleText.textSubBodyHitam14,
            ),
          ],
        ),
      ),
    );
  }

  ButtonBottom(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: DefaultButton(
            text: "Tolak",
            press: () => _settingModalBottomSheet(context),
          ),
        ),
        SizedBox(
          width: 10,
        ),
        if (widget.jadwal.ttlJadwal == null)
          Expanded(
            child: DefaultButton(
                text: "Terima", press: () => _selectTime(context)),
          ),
        if (widget.jadwal.ttlJadwal != null)
          Expanded(
            child: DefaultButton(
                text: "Menunggu",
                press: () async {
                  widget.jadwal.ttlJadwal = null;
                  await controllerJadwal.updateJadwal(widget.jadwal);
                  Navigator.pop(context);
                }),
          )
      ],
    );
  }

  _selectTime(BuildContext ctx) async {
    showModalBottomSheet(
        context: ctx,
        builder: (_) => Container(
              color: Color.fromARGB(255, 255, 255, 255),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: Get.width,
                    padding: EdgeInsets.all(10),
                    color: kPrimaryColor,
                    child: Text(
                      "Tanggal",
                      textAlign: TextAlign.center,
                      style: StyleText.textBodyPutih16,
                    ),
                  ),
                  Flexible(
                    child: Container(
                      height: 150,
                      child: CupertinoDatePicker(
                          mode: CupertinoDatePickerMode.date,
                          initialDateTime: DateTime.now(),
                          minimumYear: DateTime.now().year,
                          minimumDate: DateTime(DateTime.now().year,
                              DateTime.now().month, DateTime.now().day),
                          onDateTimeChanged: (val) {
                            setState(() {
                              _chosenDate = f.format(val);
                            });
                          }),
                    ),
                  ),
                  Container(
                    width: Get.width,
                    padding: EdgeInsets.all(10),
                    color: kPrimaryColor,
                    child: Text(
                      "Jam",
                      textAlign: TextAlign.center,
                      style: StyleText.textBodyPutih16,
                    ),
                  ),
                  Flexible(
                    child: Container(
                      height: 150,
                      child: CupertinoDatePicker(
                          mode: CupertinoDatePickerMode.time,
                          initialDateTime: DateTime.now(),
                          use24hFormat: true,
                          onDateTimeChanged: (val) {
                            setState(() {
                              _chooseTime = t.format(val);
                            });
                          }),
                    ),
                  ),
                  // Close the modal
                  Padding(
                      padding: EdgeInsets.all(10),
                      child: DefaultButton(
                          text: "Simpan",
                          press: () async {
                            Navigator.pop(context);
                            setState(() {
                              widget.jadwal.ttlJadwal = widget.jadwal
                                  .ttlJadwal = _chosenDate + " " + _chooseTime;
                              widget.jadwal.alasanJadwal = null;
                            });
                            await controllerJadwal
                                .updateJadwal(widget.jadwal)
                                .then((value) {
                              if (value.toUpperCase() == "SUKSES") {
                                if (widget.jadwal.ttlJadwal != null) {
                                  var timeDefault = new DateFormat(
                                      "EEEE, d MMMM yyyy HH:mm", "id_ID");

                                  var dateJadwal = widget.jadwal.ttlJadwal;
                                  DateTime tempDate =
                                      timeDefault.parse(dateJadwal);
                                  var dif = tempDate
                                      .difference(DateTime.now())
                                      .inSeconds;
                                  print(dif.toString() + " IN SEC");

                                  _notificationService
                                      .scheduleNotifications(widget.jadwal, dif);
                                }
                                return Navigator.pop(context);

                              }
                            });

                            //  return Navigator.pop(context);
                          }))
                ],
              ),
            ));
  }

  _settingModalBottomSheet(BuildContext context) {
    showModalBottomSheet(
        context: context,
        builder: (BuildContext bc) {
          return Container(
            height: 250,
            color: kBackgroundGrey,
            child: Wrap(
              children: <Widget>[
                Container(
                  width: Get.width,
                  padding: EdgeInsets.all(10),
                  color: kPrimaryColor,
                  child: Text(
                    "Alasan",
                    textAlign: TextAlign.center,
                    style: StyleText.textBodyPutih16,
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(20),
                  child: _buildAlasan(),
                ),
                Padding(
                  padding: EdgeInsets.all(10),
                  child: DefaultButton(
                      text: "Simpan",
                      press: () async {
                        if (fKey.currentState.validate()) {
                          //JIKA TRUE
                          fKey.currentState.save();
                          widget.jadwal.alasanJadwal = alasan;
                          widget.jadwal.ttlJadwal = null;
                          print(alasan ?? "ksong");

                          await controllerJadwal.updateJadwal(widget.jadwal);
                        }
                      }),
                )
              ],
            ),
          );
        });
  }

  _buildAlasan() {
    return Form(
      key: fKey,
      child: TextFormField(
        textInputAction: TextInputAction.done,
        onSaved: (newValue) => alasan = newValue,
        onChanged: (value) {
          if (value.isNotEmpty) {
            alasan = value;
          }
          return null;
        },
        validator: (value) {
          if (value.isEmpty) {
            //JIKA VALUE KOSONG
            return 'Alasan harus diisi atau beri tanda -'; //MAKA PESAN DITAMPILKAN
          }
          return null;
        },
        decoration: InputDecoration(
          labelText: "Alasan",
          hintText: "Masukkan Alasan Anda",
          errorStyle: TextStyle(height: 1),
          floatingLabelBehavior: FloatingLabelBehavior.always,
          suffixIcon: CustomSurffixIcon(svgIcon: "assets/icons/Lock.svg"),
        ),
      ),
    );
  }
}

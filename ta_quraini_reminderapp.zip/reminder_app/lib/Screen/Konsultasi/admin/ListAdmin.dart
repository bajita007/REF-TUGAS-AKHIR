import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:reminder_app/Model/ModelJadwal.dart';
import 'package:reminder_app/Model/ModelMhs.dart';
import 'package:reminder_app/Controller/ControllerMhs.dart';
import 'package:reminder_app/Screen/Konsultasi/admin/DialogAddDate.dart';
import 'package:reminder_app/Setup/constants.dart';
import 'package:reminder_app/Widget/CostumTextWIthLabel.dart';
import 'package:reminder_app/Widget/StyleText.dart';

class KonsultasiListAdminJadwal extends StatefulWidget {
  ModelJadwal modelJadwal;
  String status;

  KonsultasiListAdminJadwal({this.modelJadwal, this.status});

  @override
  _KonsultasiListAdminJadwalState createState() =>
      _KonsultasiListAdminJadwalState();
}

class _KonsultasiListAdminJadwalState extends State<KonsultasiListAdminJadwal> {
  ControllerMhs controlMhs = Get.put(ControllerMhs());
  String textBtn;
  String imageFile;
  ModelMhs _modelMhs;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    dataMhs(widget.modelJadwal.idMahasiswaJadwal);
    textBtn = widget.status.toUpperCase() == "SELESAI"
        ? "Selengkapnya"
        : "Tambah Jadwal";
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
        future: dataMhs(widget.modelJadwal.idMahasiswaJadwal),
        builder: (context, snapshot) {
          ModelMhs modelMhs = snapshot.data ?? ModelMhs();

          if (snapshot.connectionState == ConnectionState.waiting) {
            return SizedBox();
          } else {
            return Container(
              height: 120,
              margin: EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(20))),
              child: Row(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Card(
                      margin: EdgeInsets.all(0),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      elevation: 0.0,
                      clipBehavior: Clip.antiAlias,
                      child: Container(
                        width: 125.0,
                        height: 125.0,
                        child: ClipRRect(
                            child: modelMhs.fotoMhs == null
                                ? Image.asset(
                                    "assets/icons/logo_kecil_unm.png",
                                    color: Colors.black,
                                  )
                                : FadeInImage.assetNetwork(
                                    placeholder:
                                        "assets/icons/logo_kecil_unm.png",
                                    image: modelMhs.fotoMhs ?? "",
                                    fit: BoxFit.cover,
                                  )),
                        color: kPrimaryColor.withOpacity(0.25),
                      )),
                  SizedBox(
                    width: 10,
                  ),
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Spacer(),
                        Visibility(
                          visible: widget.status.toUpperCase() == "SELESAI"
                              ? true
                              : false,
                          child: Text(
                            widget.modelJadwal.ttlJadwal != null
                                ? widget.modelJadwal.ttlJadwal
                                : widget.modelJadwal.alasanJadwal != null
                                    ? "(Di Tolak) " +
                                        widget.modelJadwal.alasanJadwal
                                    : "-",
                            maxLines: 1,
                            style: StyleText.textTebalHitam12.copyWith(
                                color: widget.modelJadwal.ttlJadwal != null
                                    ? Colors.green
                                    : widget.modelJadwal.alasanJadwal != null
                                        ? Colors.red
                                        : Colors.white),
                          ),
                        ),
                        CostumTextLabel(
                          title: "Nama",
                          styleText: StyleText.textBiasaHitam12,
                          value: modelMhs.namaMhs ?? "Nama",
                        ),
                        CostumTextLabel(
                          title: "Nim",
                          styleText: StyleText.textBiasaHitam12,
                          value: modelMhs.nimMhs ?? "Nim",
                        ),
                        Text(
                          "(" +
                              widget.modelJadwal.judulJadwal.toUpperCase() +
                              ")",
                          maxLines: 1,
                          style: StyleText.textTebalHitam12,
                        ),
                        Spacer(),
                        Container(
                            padding: EdgeInsets.fromLTRB(10, 2, 10, 2),
                            decoration: BoxDecoration(
                              color: kPrimaryColor,
                              borderRadius: BorderRadius.circular(10.0),
                            ),
                            child: GestureDetector(
                              onTap: () {
                                return showDialog(
                                  context: context,
                                  builder: (BuildContext context) =>
                                      AddDateDialog(
                                          title: textBtn ?? "",
                                          jadwal: widget.modelJadwal,
                                          user: modelMhs,
                                          buttonText: "Ok",
                                          statusJadwal: widget.status),
                                );
                              },
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisSize: MainAxisSize.max,
                                children: <Widget>[
                                  Icon(
                                    Icons.edit,
                                    size: 15,
                                    color: Colors.white,
                                  ),
                                  const SizedBox(
                                    width: 10,
                                  ),
                                  Text(
                                    textBtn ?? "",
                                    style: StyleText.textTebalPutih12
                                        .copyWith(fontSize: 12),
                                  ),
                                ],
                              ),
                            )),
                        Spacer(),
                      ],
                    ),
                  ),
                ],
              ),
            );
          }
        });
  }

  Future dataMhs(String idMahasiswaJadwal) async {
    print(idMahasiswaJadwal + "ID MAHASISWA");
    ModelMhs data;
    data = await controlMhs.getMhs(
        user: idMahasiswaJadwal,
        pass: null,
        saveLocal: false,
        idOnly: true,
        updateData: false);

    print(data.namaMhs);
    return data;
  }
}

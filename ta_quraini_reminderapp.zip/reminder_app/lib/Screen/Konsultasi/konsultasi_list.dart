import 'package:expand_widget/expand_widget.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:reminder_app/Controller/ControllerJadwal.dart';
import 'package:reminder_app/Model/ModelJadwal.dart';
import 'package:reminder_app/Setup/constants.dart';
import 'package:reminder_app/Widget/StyleText.dart';
import 'package:reminder_app/Widget/custom_surfix_icon.dart';
import 'package:reminder_app/Widget/default_button.dart';

class KonsultasiList extends StatefulWidget {


  KonsultasiList(
      {this.modelJadwal, this.status, this.selectTap, this.selectionMode});
  ModelJadwal modelJadwal;
  String status;
  bool selectTap;
  bool selectionMode;
  @override
  _KonsultasiListState createState() => _KonsultasiListState();
}

class _KonsultasiListState extends State<KonsultasiList> {
  bool descTextShowFlag = false;
  final ControllerJadwal jadwaalControl = Get.put(ControllerJadwal());

  String title;
  String text;
  String revisi;
  var fKey = GlobalKey<FormState>();


  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 10),
      child: InkWell(
        // onLongPress: () {
        //   if (widget.status.toUpperCase() != "SELESAI") {
        //     showLoading();
        //   }
        // },
        child: Card(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0),
          ),
          elevation: 0.8,
          color: widget.selectTap ? Colors.white70 : Colors.white,
          clipBehavior: Clip.antiAlias,
          child: Stack(
            children: [
              Padding(
                padding: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            widget.modelJadwal.judulJadwal.toUpperCase(),
                            style: StyleText.textBodyHitam16,
                          ),
                          Visibility(
                            visible: widget.modelJadwal.ttlJadwal != null
                                ? true
                                : widget.modelJadwal.alasanJadwal != null
                                    ? true
                                    : false,
                            child: Text(
                              "${widget.modelJadwal.ttlJadwal != null ? widget.modelJadwal.ttlJadwal : widget.modelJadwal.alasanJadwal != null ? widget.modelJadwal.alasanJadwal : ""}",
                              style: StyleText.textTebalHitam12.copyWith(
                                  color: widget.modelJadwal.ttlJadwal != null
                                      ? Colors.green
                                      : widget.modelJadwal.alasanJadwal != null
                                          ? Colors.red
                                          : Colors.white),
                            ),
                          ),
                          Divider(),
                          ExpandText(
                            widget.modelJadwal.catatanJadwal ?? "",
                            maxLines: 3,
                            collapsedHint: "Selengkapnya",
                            capitalArrowtext: true,
                            hintTextStyle: StyleText.textSubBodyHitam14
                                .copyWith(color: kPrimaryColor),
                            expandedHint: "Sembunyikan",
                            expandWidth: true,
                            textAlign: TextAlign.justify,
                            arrowColor: kPrimaryColor,
                            expandArrowStyle: ExpandArrowStyle.both,
                            overflow: TextOverflow.ellipsis,
                            style: StyleText.textSubBodyHitam14,
                          ),
                          if (widget.status.toUpperCase() == "SELESAI") Divider(),
                          if (widget.status.toUpperCase() == "SELESAI") InkWell(
                            onTap: () {
                              return _settingModalBottomSheet(context);
                            },
                            child: ExpandText(
                              (widget.modelJadwal.revisiJadwal != null)
                                  ? "Catatan Pertemuan : " +
                                          widget.modelJadwal.revisiJadwal ??
                                      ""
                                  : "Tambahkan Catatan",
                              maxLines: 3,
                              collapsedHint: "Selengkapnya",
                              capitalArrowtext: true,
                              hintTextStyle: StyleText.textSubBodyHitam14
                                  .copyWith(color: kPrimaryColor),
                              expandedHint: "Sembunyikan",
                              expandWidth: true,
                              textAlign: TextAlign.justify,
                              arrowColor: kPrimaryColor,
                              expandArrowStyle: ExpandArrowStyle.both,
                              overflow: TextOverflow.ellipsis,
                              style: (widget.modelJadwal.revisiJadwal != null)
                                  ? StyleText.textSubBodyHitam14
                                  : StyleText.textSubBodyHitam14
                                      .copyWith(color: Colors.green),
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }



  _settingModalBottomSheet(BuildContext context) {
    return showDialog(
        context: context,
        builder: (BuildContext context) => Dialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            elevation: 0.0,
            backgroundColor: Colors.transparent,
            child: Container(
                padding: EdgeInsets.fromLTRB(10, 15, 10, 10),
                margin: EdgeInsets.only(top: 50, bottom: 50),
                decoration: new BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.rectangle,
                  borderRadius: BorderRadius.circular(15),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black26,
                      blurRadius: 20.0,
                      offset: const Offset(0.0, 30.0),
                    ),
                  ],
                ),
                child: Wrap(
                  children: <Widget>[
                    Container(
                      width: Get.width,
                      padding: EdgeInsets.all(10),
                      child: Text(
                        "Catatan Pertemuan",
                        textAlign: TextAlign.center,
                        style: StyleText.textBodyPutih16
                            .copyWith(color: kPrimaryColor),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.all(5),
                      child: _buildAlasan(),
                    ),
                    Padding(
                      padding: EdgeInsets.all(5),
                      child: DefaultButton(
                          text: "Simpan",
                          press: () async {
                            if (fKey.currentState.validate()) {
                              //JIKA TRUE
                              fKey.currentState.save();
                              widget.modelJadwal.revisiJadwal = revisi;

                              await jadwaalControl
                                  .updateJadwal(widget.modelJadwal)
                                  .then((value) {
                                if (value.toUpperCase() == "SUKSES") {
                                  Get.back();
                                }
                              });
                            }
                          }),
                    )
                  ],
                ))));
  }


  _buildAlasan() {
    return Form(
      key: fKey,
      child: TextFormField(
        textInputAction: TextInputAction.done,
        minLines: 3,
        maxLines: 10,
        initialValue: (widget.modelJadwal.revisiJadwal != null)
            ? widget.modelJadwal.revisiJadwal
            : "",
        onSaved: (newValue) => revisi = newValue,
        onChanged: (value) {
          if (value.isNotEmpty) {
            revisi = value;
          }
          return null;
        },
        validator: (value) {
          if (value.isEmpty) {
            //JIKA VALUE KOSONG
            return 'Catatan Pertemuan harus diisi atau beri tanda -'; //MAKA PESAN DITAMPILKAN
          }
          return null;
        },
        decoration: InputDecoration(
          labelText: "Catatan Pertemuan",
          hintText: "Masukkan Catatan Pertemuan Anda",
          errorStyle: TextStyle(height: 1),
          enabledBorder: const OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.grey, width: 0.0),
          ),
          floatingLabelBehavior: FloatingLabelBehavior.always,
        ),
      ),
    );
  }
}

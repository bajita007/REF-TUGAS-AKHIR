import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:grouped_list/grouped_list.dart';
import 'package:reminder_app/Model/ModelDosen.dart';
import 'package:reminder_app/Model/ModelJadwal.dart';
import 'package:reminder_app/Model/ModelMhs.dart';
import 'package:reminder_app/Controller/ControllerDsn.dart';
import 'package:reminder_app/Controller/ControllerJadwal.dart';
import 'package:reminder_app/Controller/ControllerMhs.dart';
import 'package:reminder_app/PdfCreate/PdfCreateControl.dart';
import 'package:reminder_app/PdfCreate/PdfPrinterData.dart';
import 'package:reminder_app/Screen/Konsultasi/admin/ListAdmin.dart';
import 'package:reminder_app/Screen/Konsultasi/konsultasi_list.dart';
import 'package:reminder_app/Screen/Konsultasi/menunggu/konsultasi_list_menunggu.dart';
import 'package:reminder_app/Setup/constants.dart';
import 'package:reminder_app/Setup/size_config.dart';
import 'package:reminder_app/Widget/StyleText.dart';
import 'package:reminder_app/Widget/custom_surfix_icon.dart';
import 'package:reminder_app/Widget/default_button.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'RefreshDataWidget.dart';

class KonsultasiScreen extends StatefulWidget {
  static String routeName = "/Screen.tester";
  String status;

  KonsultasiScreen({this.status});

  @override
  _KonsultasiScreenState createState() => _KonsultasiScreenState();
}

class _KonsultasiScreenState extends State<KonsultasiScreen> {
  ModelJadwal modelJadwal;
  ControllerDsn controlDsn = Get.put(ControllerDsn());
  ControllerMhs controlMhs = Get.put(ControllerMhs());
  ControllerJadwal controlJadwal = Get.put(ControllerJadwal());
  final keyRefresh = GlobalKey<RefreshIndicatorState>();
  List<ModelJadwal> listJadwal = [];
  List<ModelJadwal> jadwalPrint = [];
  var data;
  var placeholder = "assets/icons/logo_kecil_unm.png";
  ByteData imageData;

  //OnSelectData
  Map<int, bool> selectedFlag = {};

  String roleUser;
  String idUser;
  bool loading = true;
  bool dataNull = true;
  bool change = false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    loadAsset();
    loadList();
  }

  loadAsset() async {
    var data = await rootBundle.load(placeholder);
    if (mounted) setState(() => this.imageData = data);
  }

  Future loadList() async {
    keyRefresh.currentState?.show();
    SharedPreferences loginCheck = await SharedPreferences.getInstance();
    idUser = loginCheck.getString(LoginValue.idLogin);
    roleUser = loginCheck.getString(LoginValue.idRole);

    print(roleUser);
    controlJadwal.getJadwalAll(idUser, roleUser, widget.status);

    if (mounted)
      setState(() {
        loading = false;
      });
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    keyRefresh.currentState?.dispose();
  }

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: Visibility(
        visible:
            widget.status.toUpperCase() == "SELESAI" && jadwalPrint.length >0
                ? true
                : false,
        child: FloatingActionButton.extended(
          onPressed: () async {
            return PdfCreateControl().generateInvoice(
                modelJadwal: jadwalPrint, modelMhs: await setDataUser());
          },
          backgroundColor: kPrimaryColor,
          icon: Icon(Icons.print),
          label: Text('Print ${jadwalPrint.length ?? "0"}'),
        ),
      ),
      body: Container(
        color: kBackgroundGrey,
        width: SizeConfig.screenWidth,
        height: SizeConfig.screenHeight,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
          child: buildList(),
        ),
      ),
    );
  }

  Widget buildList() => loading
      ? Container(child: Center(child: CircularProgressIndicator()))
      : RefreshWidget(
          keyRefresh: keyRefresh,
          onRefresh: loadList,
          child: GetX<ControllerJadwal>(
            init: Get.put<ControllerJadwal>(ControllerJadwal()
                .getJadwalAll(idUser, roleUser, widget.status)),
            builder: (ControllerJadwal listJadwal) {

              if (listJadwal != null &&
                  listJadwal.jadwals != null &&
                  listJadwal.jadwals.length != 0) {
                return GroupedListView<dynamic, String>(
                    padding: EdgeInsets.all(0),
                    elements: listJadwal.jadwals,
                    groupBy: (jadwal) => jadwal.idDosenJadwal,
                    groupComparator: (value1, value2) =>
                        value2.compareTo(value1),
                    itemComparator: (item1, item2) =>
                        item1.judulJadwal.compareTo(item2.judulJadwal),
                    order: GroupedListOrder.DESC,
                    floatingHeader: true,
                    groupSeparatorBuilder: (value) =>
                        roleUser.contains("Dosen") ||
                                widget.status == "Berlangsung"
                            ? null
                            : HeaderGroup(value),
                    indexedItemBuilder: (c, element, index) {
                      selectedFlag[index] = selectedFlag[index] ?? false;
                      bool isSelected = selectedFlag[index];
                      ModelJadwal modelJadwal = element;
                      // onTaps(isSelected, index, modelJadwal);
                      if (widget.status == "Berlangsung" &&
                          modelJadwal.ttlJadwal != null) {
                        return KonsultasiListMenunggu(
                            modelJadwal: element, status: widget.status);
                      } else {
                        if (roleUser.contains("Dosen")) {
                          return KonsultasiListAdminJadwal(
                              modelJadwal: element, status: widget.status);
                        } else {
                          print("OKEEE");
                          return InkWell(
                            onLongPress: () {
                              if (widget.status.toUpperCase() != "SELESAI") {
                                return showLoading(modelJadwal);
                              }else {
                                return onTaps(isSelected, index, modelJadwal);
                              }

                            },

                            child: KonsultasiList(
                              modelJadwal: element,
                              status: widget.status,
                              selectTap: isSelected,
                            ),
                          );
                        }
                      }
                    });
              } else {
                return Container(
                  child: Center(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        CustomSurffixIcon(
                          svgIcon: "assets/icons/Conversation.svg",
                          size: 150,
                        ),
                        Text("Anda Belum Melakukan Konsultasi")
                      ],
                    ),
                  ),
                );
              }
              // else {
              //   return Container(
              //       child: Center(child: CircularProgressIndicator()));
              // }
            },
          ),
        );

  Widget HeaderGroup(String value) {
    return FutureBuilder(
        future: dataDosen(value),
        builder: (context, snapshot) {

          if (snapshot.connectionState == ConnectionState.waiting &&
              snapshot.data == null) {
            return SizedBox();
          }
          ModelDosen modelDosen = snapshot.data;
          return Container(
            margin: EdgeInsets.symmetric(vertical: 10),
            child: Card(
              margin: EdgeInsets.all(0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
              ),
              elevation: 0.0,
              clipBehavior: Clip.antiAlias,
              color: Colors.white,
              child: Container(
                height: 75,
                child: Row(
                  children: [
                    Container(
                        width: 75.0,
                        height: 75.0,
                        child: modelDosen.fotoDsn == null
                            ? Image.asset(
                                placeholder,
                                color: Colors.white,
                              )
                            : FadeInImage.assetNetwork(
                                placeholder: placeholder,
                                image: snapshot.data.fotoDsn,
                                fit: BoxFit.cover,
                              ),
                        decoration: new BoxDecoration(
                          color: kPrimaryColor,
                          borderRadius: BorderRadius.circular(10.0),
                        )),
                    SizedBox(
                      width: 10,
                    ),
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            modelDosen.namaDsn.toUpperCase() ?? "",
                            style: StyleText.textTebalHitam12
                                .copyWith(fontSize: 14),
                          ),
                          Text(
                            "Nip : " + modelDosen.nipDsn ?? "",
                            style: StyleText.textBiasaHitam12
                                .copyWith(fontSize: 14),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
          );
        });
  }

 onTaps(bool isSelected, int index, ModelJadwal modelJadwal) async {
    //ModelDosen modelDosen = await dataDosen(modelJadwal.idDosenJadwal);

    if (!jadwalPrint.contains(modelJadwal)) {
      setState(() {
        jadwalPrint.add(modelJadwal);
      });
    } else {
      setState(() {
        jadwalPrint.remove(modelJadwal);
      });
    }
    setState(() {
      selectedFlag[index] = !isSelected;
    });
  }

  setDataUser() async {
    SharedPreferences loginCheck = await SharedPreferences.getInstance();
    String nimNip = loginCheck.getString(LoginValue.idLogin);
    ModelMhs modelMhs = await controlMhs.getMhs(
        user: nimNip,
        pass: null,
        saveLocal: false,
        idOnly: true,
        updateData: false);

    return modelMhs;
  }

  dataDosen(String value) async {
    ModelDosen modelDosen = await controlDsn.getDsn(
        user: value,
        pass: null,
        saveLocal: false,
        idOnly: true,
        updateData: false);
    return modelDosen;
  }

  showLoading(ModelJadwal modelJadwal) {
    Get.dialog(
      AlertDialog(
        title: Text('Hapus Data'),
        content: new Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                if (change) new CircularProgressIndicator(),
                if (change) SizedBox(width: 10),
                Expanded(
                  child: new Text(

                        "Apakah Anda Ingin Menghapus Data dari " +
                            modelJadwal.judulJadwal +
                            " ?",
                    style: StyleText.textBiasaHitam14,
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 15,
            ),
            Row(
              children: [
                Flexible(
                  child: DefaultButton(
                    press: () {
                      Navigator.pop(context);
                    },
                    text: "Batal",
                  ),
                ),
                SizedBox(
                  width: 12,
                ),
                Flexible(
                  child: DefaultButton(
                    press: () {
                      controlJadwal.deleteJadwal(modelJadwal.idJadwal);
                      Navigator.pop(context);
                    },
                    text: "Ya",
                  ),
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}

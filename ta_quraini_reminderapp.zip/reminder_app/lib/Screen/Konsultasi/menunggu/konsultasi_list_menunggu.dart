import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:reminder_app/Controller/ControllerMhs.dart';
import 'package:reminder_app/Model/ModelJadwal.dart';
import 'package:reminder_app/Model/ModelMhs.dart';
import 'package:reminder_app/Screen/Konsultasi/admin/DialogAddDate.dart';
import 'package:reminder_app/Setup/themes.dart';
import 'package:reminder_app/Widget/StyleText.dart';

class KonsultasiListMenunggu extends StatefulWidget {
  ModelJadwal modelJadwal;
  String status;

  KonsultasiListMenunggu({this.modelJadwal, this.status});

  @override
  _KonsultasiListMenungguState createState() => _KonsultasiListMenungguState();
}

class _KonsultasiListMenungguState extends State<KonsultasiListMenunggu> {
  String statusKonsultasi;
  var fKey = GlobalKey<FormState>();
  var timeDefault = new DateFormat("EEEE, d MMMM yyyy HH:mm", "id_ID");

  ControllerMhs controlMhs = Get.put(ControllerMhs());
  ModelMhs modelMhs;
  String hari = "";
  String jam = "";

  getDays() {
    if (widget.modelJadwal.ttlJadwal != null) {
      DateTime parseDate = timeDefault.parse(widget.modelJadwal.ttlJadwal);
      var inputDate = DateTime.parse(parseDate.toString());
      var outputFormat = DateFormat('EEEE,dd-MMMM-yyyy', "id_ID");
      var day = outputFormat.format(inputDate);
      print(day);
      setState(() {
        hari = day;
      });
      return day;
    }
  }

  getTimes() {
    if (widget.modelJadwal.ttlJadwal != null) {
      DateTime parseDate = timeDefault.parse(widget.modelJadwal.ttlJadwal);
      DateTime inputDate = DateTime.parse(parseDate.toString());
      DateFormat format = DateFormat.Hm();
      var time = format.format(inputDate);
      setState(() {
        jam = time;
      });
      return time;
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    dataMhs();
    getDays();
    getTimes();
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        if (modelMhs != null)
          return showDialog(
            context: context,
            builder: (BuildContext context) => AddDateDialog(
                title: "JADWAL",
                jadwal: widget.modelJadwal,
                user: modelMhs,
                buttonText: "Okay",
                statusJadwal: widget.status),
          );
      },
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 5),
        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.orange, Colors.deepOrange],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          boxShadow: [
            BoxShadow(
              color: GradientColors.sunset.last.withOpacity(0.4),
              blurRadius: 8,
              spreadRadius: 2,
              offset: Offset(4, 4),
            ),
          ],
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              mainAxisSize: MainAxisSize.max,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Icon(
                      Icons.label,
                      color: Colors.white,
                      size: 30,
                    ),
                    SizedBox(width: 8),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        if (modelMhs != null)
                          Text(
                            modelMhs.namaMhs.toUpperCase() ?? "",
                            style: StyleText.textTebalPutih12,
                          ),
                        Text(
                          widget.modelJadwal.judulJadwal,
                          maxLines: 1,
                          style: StyleText.textTebalPutih12,
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
            Divider(
              color: Colors.white54,
            ),
            Row(
              children: [
                Icon(
                  Icons.timer,
                  color: Colors.white,
                  size: 30,
                ),
                SizedBox(width: 8),
                Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(jam + " WITA", style: StyleText.textTebalPutih12),
                    Text(hari ?? "", style: StyleText.textTebalPutih12),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  dataMhs() async {
    ModelMhs model;

    model = await controlMhs.getMhs(
        user: widget.modelJadwal.idMahasiswaJadwal,
        pass: null,
        saveLocal: false,
        idOnly: true,
        updateData: false);

    setState(() {
      modelMhs = model;
    });
    return model ?? ModelMhs();
  }
}

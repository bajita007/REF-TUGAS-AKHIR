import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:reminder_app/Controller/ControllerDsn.dart';
import 'package:reminder_app/Controller/ControllerMhs.dart';
import 'package:reminder_app/Screen/Home/HomeScreen.dart';
import 'package:reminder_app/Setup/constants.dart';
import 'package:reminder_app/Setup/size_config.dart';
import 'package:reminder_app/Widget/custom_surfix_icon.dart';
import 'package:reminder_app/Widget/default_button.dart';
import 'package:reminder_app/Widget/form_error.dart';

import '../../OneSignal.dart';

class LoginForm extends StatefulWidget {
  @override
  _LoginFormState createState() => _LoginFormState();
}

class _LoginFormState extends State<LoginForm> {
  @override
  final _formKey = GlobalKey<FormState>();
  String email;
  String password;
  int id = 1;
  String radioButtonItem = 'Mahasiswa';
  bool remember;

  final controlMhs = Get.put(ControllerMhs());
  final controlDsn = Get.put(ControllerDsn());

  String tokenIdUser;

  final List<String> errors = [];

  void addError({String error}) {
    if (!errors.contains(error))
      setState(() {
        errors.add(error);
      });
  }

  void removeError({String error}) {
    if (errors.contains(error))
      setState(() {
        errors.remove(error);
      });
  }

  @override
  initState() {
    // TODO: implement initState
    super.initState();
    // setToken();
    remember = true;
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          buildEmailFormField(),
          SizedBox(height: getProportionateScreenHeight(15)),
          buildPasswordFormField(),
          SizedBox(height: getProportionateScreenHeight(15)),
          SizedBox(height: getProportionateScreenHeight(15)),
          buildRadioButton(),
          buildShowPass(),
          FormError(errors: errors),
          SizedBox(height: getProportionateScreenHeight(15)),
          DefaultButton(
            text: "Masuk",
            press: () async {
              var status = await Permission.storage.status;
              var status2 = await Permission.accessMediaLocation.status;
              var status3 = await Permission.manageExternalStorage.status;


              if (status.isGranted && status2.isGranted && status3.isGranted) {
                setDataLogin();
              } else if (status.isDenied) {
                await Permission.storage.request();
                await Permission.accessMediaLocation.request();
                await Permission.manageExternalStorage.request();


              }
            },
          ),
        ],
      ),
    );
  }

  TextFormField buildPasswordFormField() {
    return TextFormField(
      obscureText: !remember,
      textInputAction: TextInputAction.done,
      onSaved: (newValue) => password = newValue,
      onChanged: (value) {
        if (value.isNotEmpty) {
          removeError(error: kPassNullError);
        } else if (value.length >= 6) {
          removeError(error: kShortPassError);
        }
        password = value;
      },
      validator: (value) {
        if (value.isEmpty) {
          addError(error: kPassNullError);
          return "";
        } else if (value.length < 6) {
          addError(error: kShortPassError);
          return "";
        }
        return null;
      },
      decoration: InputDecoration(
        labelText: "Kata Sandi",
        hintText: "Masukkan kata Sandi",
        // If  you are using latest version of flutter then lable text and hint text shown like this
        // if you r using flutter less then 1.20.* then maybe this is not working properly
        floatingLabelBehavior: FloatingLabelBehavior.always,
        errorStyle: TextStyle(height: 0),
        suffixIcon: CustomSurffixIcon(svgIcon: "assets/icons/Lock.svg"),
      ),
    );
  }

  TextFormField buildEmailFormField() {
    return TextFormField(
      keyboardType: TextInputType.emailAddress,
      textInputAction: TextInputAction.next,
      onSaved: (newValue) => email = newValue,
      onChanged: (value) {
        if (value.isNotEmpty) {
          removeError(error: kEmailNullError);
        }
        return null;
      },
      validator: (value) {
        if (value.isEmpty) {
          addError(error: kEmailNullError);
          return "";
        }
        return null;
      },
      decoration: InputDecoration(
        labelText: "Email",
        hintText: "Masukkan Email",
        errorStyle: TextStyle(height: 0),

        // If  you are using latest version of flutter then lable text and hint text shown like this
        // if you r using flutter less then 1.20.* then maybe this is not working properly
        floatingLabelBehavior: FloatingLabelBehavior.always,
        suffixIcon: CustomSurffixIcon(svgIcon: "assets/icons/Mail.svg"),
      ),
    );
  }

  CheckboxListTile buildShowPass() {
    return CheckboxListTile(
        value: remember,
        contentPadding: EdgeInsets.all(0),
        controlAffinity: ListTileControlAffinity.leading,
        title: Text("Tampilkan Kata Sandi"),
        activeColor: kPrimaryColor,
        onChanged: (bool newValue) {
          setState(() {
            print(newValue);
            remember = newValue;
          });
        });
  }

  buildRadioButton() {
    return Container(
      padding: EdgeInsets.all(10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: Colors.white,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Text(
            'Sebagai :',
          ),
          Radio(
            value: 1,
            groupValue: id,
            activeColor: kPrimaryColor,
            onChanged: (val) {
              setState(() {
                radioButtonItem = 'Mahasiswa';
                id = 1;
                print(radioButtonItem);
              });
            },
          ),
          Text(
            'Mahasiswa',
            style: TextStyle(color: (id == 1) ? kPrimaryColor : kTextColor),
          ),
          Radio(
            value: 2,
            groupValue: id,
            activeColor: kPrimaryColor,
            onChanged: (val) {
              setState(() {
                radioButtonItem = 'Dosen';
                id = 2;
                print(radioButtonItem);
              });
            },
          ),
          Text(
            'Dosen',
            style: TextStyle(color: (id == 2) ? kPrimaryColor : kTextColor),
          ),
        ],
      ),
    );
  }

  Future<void> checkDataLogin(data) async {
    if (data != null) {
      Get.offAllNamed(HomePage.routeName);
    } else {
      Get.rawSnackbar(
          title: 'Gagal Login',
          message: 'Data Anda Tidak Di Temukan Silahkan Periksa Kembali',
          backgroundColor: Colors.red[600],
          icon: Icon(Icons.warning, color: Colors.white));
    }
  }

  Future<void> setDataLogin() async {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();
      var data;
      print(radioButtonItem + " " + email);
      if (radioButtonItem.contains("Dosen")) {
        print("Login DOSEN");
        data = await controlDsn.getDsn(
            user: email,
            pass: password,
            saveLocal: true,
            updateData: true,
            idOnly: false);
      } else {
        print("Login Mahasiswa");
        data = await controlMhs.getMhs(
            user: email,
            pass: password,
            saveLocal: true,
            updateData: true,
            login: true,
            idOnly: false);
      } // i
      print(data);

      checkDataLogin(data); // f all are valid then go to success screen
    }
  }

// Future<void> setToken() async {
//   tokenIdUser = await NotifikasiSetup().getIdUser();
// }

}

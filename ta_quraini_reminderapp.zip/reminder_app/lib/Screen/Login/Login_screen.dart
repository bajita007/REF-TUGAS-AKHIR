import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:reminder_app/Screen/Login/Login_form.dart';
import 'package:reminder_app/Screen/register/Register_screen.dart';
import 'package:reminder_app/Setup/constants.dart';
import 'package:reminder_app/Setup/size_config.dart';
import 'package:reminder_app/Widget/StyleText.dart';

class LoginScreen extends StatefulWidget {
  static String routeName = "/Screen.login";

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      body: Container(
        height: double.infinity,
        color: kBackgroundGrey,
        child: SafeArea(
          child: SizedBox(
            width: double.infinity,
            child: Stack(
              children: [
                Padding(
                  padding: EdgeInsets.symmetric(
                      horizontal: getProportionateScreenWidth(20)),
                  child: SingleChildScrollView(
                      physics: BouncingScrollPhysics(),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                              height: SizeConfig.screenHeight * 0.04), // 4%
                          Text("Selamat Datang Kembali di",
                              textAlign: TextAlign.center,
                              style: StyleText.textHeaderHitam24),
                          Text("Reminder App",
                              textAlign: TextAlign.center,
                              style:
                                  headingStyle.copyWith(color: kPrimaryColor)),
                          SizedBox(height: SizeConfig.screenHeight * 0.02),
                          logo(75),
                          SizedBox(height: SizeConfig.screenHeight * 0.05),
                          LoginForm(),
                          SizedBox(height: SizeConfig.screenHeight * 0.02),

                          Row(
                            mainAxisSize: MainAxisSize.max,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                'Anda Belum Memiliki Akun.?',
                                textAlign: TextAlign.center,
                                style: Theme.of(context).textTheme.caption,
                              ),
                              GestureDetector(
                                child: Text(
                                  ' Daftar',
                                  textAlign: TextAlign.center,
                                  style: StyleText.textSubBodyPutih14
                                      .copyWith(color: kPrimaryColor),
                                ),
                                onTap: () =>
                                    Get.toNamed(ScreenRegister.routeName),
                              ),
                            ],
                          )
                        ],
                      )),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

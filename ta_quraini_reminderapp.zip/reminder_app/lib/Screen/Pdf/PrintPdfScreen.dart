import 'package:flutter/material.dart';
import 'package:reminder_app/PdfCreate/PdfCreateControl.dart';

class PrintPdfView extends StatefulWidget {
  static String routeName = "/Screen.PrintPDF";

  @override
  _PrintPdfViewState createState() => _PrintPdfViewState();
}

class _PrintPdfViewState extends State<PrintPdfView> {
  String namaFile = "Ini Nama FIle";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            TextButton(
                child: Text('Generate PDF'),
                style: TextButton.styleFrom(
                  primary: Colors.white,
                  backgroundColor: Colors.lightBlue,
                  onSurface: Colors.grey,
                ),
                onPressed: () {
                  return PdfCreateControl()
                      .generateInvoice(nama: namaFile.toString());
                })
          ],
        ),
      ),
    );
  }
}

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:reminder_app/Screen/Home/HomeScreen.dart';
import 'package:reminder_app/Screen/Login/Login_screen.dart';
import 'package:reminder_app/Setup/constants.dart';
import 'package:reminder_app/Setup/size_config.dart';
import 'package:reminder_app/Widget/StyleText.dart';
import 'package:reminder_app/Widget/TopHeader.dart';
import 'package:reminder_app/Widget/circle.dart';
import 'package:reminder_app/Widget/custom_surfix_icon.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SplashView extends StatefulWidget {
  static String routeName = "/Screen.splash";

  @override
  _SplashViewState createState() => _SplashViewState();
}

class _SplashViewState extends State<SplashView> {
  @override
  void initState() {
    super.initState();
    startLaunching();
  }

  startLaunching() async {
    SharedPreferences loginCheck = await SharedPreferences.getInstance();
    var data = loginCheck.get(LoginValue.idRole);

    var duration = const Duration(seconds: 3);
    return new Timer(duration, () async {
      String seen = loginCheck.get(LoginValue.idLogin);

      if (seen == null) {
        Get.offAllNamed(LoginScreen.routeName);
      } else {
        Get.offAllNamed(HomePage.routeName, arguments: data);
      }
    });
  }

  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
        body: Container(
            child: Stack(children: <Widget>[
      Align(
        alignment: Alignment.bottomLeft,
        child: CustomPaint(
          painter: CircleOne(Colors.blue.withAlpha(80)),
        ),
      ),
      Align(
        alignment: Alignment.bottomRight,
        child: CustomPaint(
          painter: CircleTwo(Colors.lightGreenAccent.withAlpha(80)),
        ),
      ),
      Align(
        alignment: Alignment(-1.0, -0.4),
        child: CustomPaint(
          painter: CircleTwo(Colors.red.withAlpha(80)),
        ),
      ),
      Align(
        alignment: Alignment(0.0, 0.4),
        child: CustomPaint(
          painter: CircleOne(Colors.blue.withAlpha(80)),
        ),
      ),
      Align(
        alignment: Alignment(1.0, 0.0),
        child: CustomPaint(
          painter: CircleTwo(Colors.yellowAccent.withAlpha(80)),
        ),
      ),
      ClipPath(
        clipper: Header3(),
        child: Container(
          color: kBackgroundGrey.withOpacity(0.05),
        ),
      ),
      ClipPath(
        clipper: Header2(),
        child: Container(
          color: kPrimaryColor,
        ),
      ),

      Center(
        child: Padding(
          padding: EdgeInsets.all(10),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                "assets/icons/reminders.png",
                width: 50,
                height: 50,
              ),
              Text(
                "Reminder App",
                style: StyleText.textSubHeaderHitam20,
              ),
            ],
          ),
        ),
      )
      //
    ])));
  }
}

import 'package:flutter/material.dart';
import 'package:reminder_app/Setup/constants.dart';
import 'package:reminder_app/Setup/size_config.dart';

import 'complete_profile_form.dart';

class Body extends StatelessWidget {
  String emailUser;
  String passUser;
  String status;
  final keyRefresh = GlobalKey<RefreshIndicatorState>();

  Body(
      {@required this.emailUser,
      @required this.passUser,
      @required this.status});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: Padding(
        padding:
            EdgeInsets.symmetric(horizontal: getProportionateScreenWidth(20)),
        child: SingleChildScrollView(
          // key: keyRefresh,
          physics: BouncingScrollPhysics(),
          child: Column(
            children: [
              SizedBox(height: SizeConfig.screenHeight * 0.04),
              Text("Lengkapi Profil", style: headingStyle),
              SizedBox(height: SizeConfig.screenHeight * 0.02),
              CompleteProfileForm(
                status: status,
                passUser: passUser,
                emailUser: emailUser,
              ),
              SizedBox(height: getProportionateScreenHeight(30)),
            ],
          ),
        ),
      ),
    );
  }
}

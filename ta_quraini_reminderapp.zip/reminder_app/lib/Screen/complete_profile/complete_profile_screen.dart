import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:reminder_app/Setup/constants.dart';
import 'package:reminder_app/Setup/size_config.dart';
import 'package:reminder_app/Widget/DefaultOnback.dart';

import 'body.dart';

class CompleteProfileScreen extends StatelessWidget {
  String emailUser = Get.arguments[0] ?? "";
  String passUser = Get.arguments[1] ?? "";
  String statusMahasiswa = Get.arguments[2] ?? "";

  static String routeName = "/Screen.complete_profile";
  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      body: SafeArea(
        child: Container(
          color: kBackgroundGrey,
          height: double.infinity,
          child: Stack(
            children: [
              Body(
                  emailUser: emailUser,
                  passUser: passUser,
                  status: statusMahasiswa),
              DefaultOnBackButton(
                status: null,
                colors: kPrimaryColor,
                colorsIcon: Colors.white,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:reminder_app/Setup/constants.dart';
import 'package:reminder_app/Setup/size_config.dart';

import 'complete_profile_form_dosen.dart';

class Body extends StatelessWidget {
  String emailUser;
  String passUser;
  String status;
  Body(
      {@required this.emailUser,
      @required this.passUser,
      @required this.status});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: Padding(
        padding:
            EdgeInsets.symmetric(horizontal: getProportionateScreenWidth(20)),
        child: SingleChildScrollView(
          physics: BouncingScrollPhysics(),
          child: Column(
            children: [
              SizedBox(height: SizeConfig.screenHeight * 0.03),
              SizedBox(
                height: getProportionateScreenWidth(40),
              ),
              Text("Lengkapi Profil", style: headingStyle),
              SizedBox(height: SizeConfig.screenHeight * 0.06),
              CompleteProfileFormDosen(
                status: status,
                passUser: passUser,
                emailUser: emailUser,
              ),
              SizedBox(height: getProportionateScreenHeight(30)),
            ],
          ),
        ),
      ),
    );
  }
}

import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:reminder_app/Model/ModelDosen.dart';
import 'package:reminder_app/Api/ApiDsnMahasiswa.dart';
import 'package:reminder_app/Screen/Home/HomeScreen.dart';
import 'package:reminder_app/Setup/constants.dart';
import 'package:reminder_app/Setup/size_config.dart';
import 'package:reminder_app/Widget/StyleText.dart';
import 'package:reminder_app/Widget/custom_surfix_icon.dart';
import 'package:reminder_app/Widget/default_button.dart';
import 'package:reminder_app/Widget/form_error.dart';

class CompleteProfileFormDosen extends StatefulWidget {
  String emailUser;
  String passUser;
  String status;

  CompleteProfileFormDosen(
      {@required this.emailUser,
      @required this.passUser,
      @required this.status});

  @override
  _CompleteProfileFormDosenState createState() =>
      _CompleteProfileFormDosenState();
}

class _CompleteProfileFormDosenState extends State<CompleteProfileFormDosen> {
  final _formKey = GlobalKey<FormState>();
  final List<String> errors = [];
  TextEditingController dateCtl = TextEditingController();
  final picker = ImagePicker();

  String nip;
  String namaLengkap;
  String phoneNumber;
  String dateTime;
  String address;
  String tokenIdUser;

  final focus = FocusNode();
  var f = new DateFormat("EEEE, d MMMM yyyy", "id_ID");
  var imageFile;
  ModelDosen modelDosen;

  @override
  initState() {
    // TODO: implement initState
    super.initState();
  }

  void addError({String error}) {
    if (!errors.contains(error))
      setState(() {
        errors.add(error);
      });
  }

  void removeError({String error}) {
    if (errors.contains(error))
      setState(() {
        errors.remove(error);
      });
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    dateCtl?.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          //Nim
          buildImageAdd(),
          SizedBox(height: getProportionateScreenHeight(15)),
          buildNimFormField(),
          SizedBox(height: getProportionateScreenHeight(15)),
          buildNamaLengkapFormField(),
          SizedBox(height: getProportionateScreenHeight(15)),
          buildTanggalLahirFormField(),
          SizedBox(height: getProportionateScreenHeight(15)),
          buildPhoneNumberFormField(),
          SizedBox(height: getProportionateScreenHeight(15)),
          buildAddressFormField(),
          SizedBox(height: getProportionateScreenHeight(15)),
          FormError(errors: errors),
          SizedBox(height: getProportionateScreenHeight(15)),
          DefaultButton(
            text: "Simpan",
            press: () {
              if (_formKey.currentState.validate()) {
                _formKey.currentState.save();
                modelDosen = ModelDosen(
                  nipDsn: nip,
                  namaDsn: namaLengkap,
                  alamatDsn: address,
                  emailDsn: widget.emailUser,
                  tokenDsn: tokenIdUser,
                  fotoDsn: null,
                  stsDsn: "Dosen",
                  noDsn: phoneNumber,
                  ttlDsn: dateCtl.text,
                  passDsn: widget.passUser,
                );

                saveDataDosen();
                //
              }
            },
          ),
        ],
      ),
    );
  }

  Future<void> saveDataDosen() async {
    ModelDosen data = await ApiDsnMhs()
        .createDsn(modelDosen: modelDosen, file: imageFile, saveLocal: true);
    if (data != null) {
      Get.offAllNamed(HomePage.routeName);
    } else {
      Get.rawSnackbar(
        title: "Anda Sedang Offline",
        message: 'Gagal Simpan data',
        backgroundColor: Colors.red[600],
      );
    }
  }

  TextFormField buildAddressFormField() {
    return TextFormField(
      keyboardType: TextInputType.streetAddress,
      onSaved: (newValue) => address = newValue,
      maxLines: 6,
      minLines: 3,
      textInputAction: TextInputAction.done,
      onChanged: (value) {
        if (value.isNotEmpty) {
          removeError(error: kAddressNullError);
        }
        return null;
      },
      validator: (value) {
        if (value.isEmpty) {
          addError(error: kAddressNullError);
          return "";
        }
        return null;
      },
      decoration: InputDecoration(
        labelText: "Alamat",

        hintText: "Alamat Tempat Tinggal",
        errorStyle: TextStyle(height: 0),
        // If  you are using latest version of flutter then lable text and hint text shown like this
        // if you r using flutter less then 1.20.* then maybe this is not working properly
        floatingLabelBehavior: FloatingLabelBehavior.always,
        suffixIcon:
            CustomSurffixIcon(svgIcon: "assets/icons/Location point.svg"),
      ),
    );
  }

  TextFormField buildPhoneNumberFormField() {
    return TextFormField(
      textInputAction: TextInputAction.next,
      keyboardType: TextInputType.phone,
      onSaved: (newValue) => phoneNumber = newValue,
      onChanged: (value) {
        if (value.isNotEmpty) {
          removeError(error: "Masukkan No Telpon / No Hp  Anda");
        }
        return null;
      },
      validator: (value) {
        if (value.isEmpty) {
          addError(error: "Masukkan No Telpon / No Hp Anda");
          return "";
        }
        return null;
      },
      decoration: InputDecoration(
        labelText: "No Telpon / No Hp",
        errorStyle: TextStyle(height: 0),

        hintText: "No Telpon / No Hp",
        // If  you are using latest version of flutter then lable text and hint text shown like this
        // if you r using flutter less then 1.20.* then maybe this is not working properly
        floatingLabelBehavior: FloatingLabelBehavior.always,
        suffixIcon: CustomSurffixIcon(svgIcon: "assets/icons/Phone.svg"),
      ),
    );
  }

  TextFormField buildNamaLengkapFormField() {
    return TextFormField(
      textInputAction: TextInputAction.next,
      onSaved: (newValue) => namaLengkap = newValue,
      onChanged: (value) {
        if (value.isNotEmpty) {
          removeError(error: kNamaNullErro);
        }
        return null;
      },
      validator: (value) {
        if (value.isEmpty) {
          addError(error: kNamaNullErro);
          return "";
        }
        return null;
      },
      decoration: InputDecoration(
        labelText: "Nama Lengkap",
        hintText: "Nama Lengkap",
        errorStyle: TextStyle(height: 0),

        // If  you are using latest version of flutter then lable text and hint text shown like this
        // if you r using flutter less then 1.20.* then maybe this is not working properly
        floatingLabelBehavior: FloatingLabelBehavior.always,
        suffixIcon: CustomSurffixIcon(svgIcon: "assets/icons/User.svg"),
      ),
    );
  }

  TextFormField buildNimFormField() {
    return TextFormField(
      textInputAction: TextInputAction.next,
      keyboardType: TextInputType.number,
      onSaved: (newValue) => nip = newValue,
      onChanged: (value) {
        if (value.isNotEmpty) {
          removeError(error: kNipNullError);
        }
        return null;
      },
      validator: (value) {
        if (value.isEmpty && value.isNum) {
          addError(error: kNipNullError);
          return "";
        }
        return null;
      },
      decoration: InputDecoration(
        labelText: "Nip",

        hintText: "Nip",
        errorStyle: TextStyle(height: 0),

        // If  you are using latest version of flutter then lable text and hint text shown like this
        // if you r using flutter less then 1.20.* then maybe this is not working properly
        floatingLabelBehavior: FloatingLabelBehavior.always,
        suffixIcon: CustomSurffixIcon(svgIcon: "assets/icons/User.svg"),
      ),
    );
  }


  buildImageAdd() {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15.0),
      ),
      elevation: 0.0,
      clipBehavior: Clip.antiAlias,
      shadowColor: null,
      color: Colors.white,
      child: Container(
        height: 150,
        color: Colors.white,
        width: 150,
        child: Stack(
          children: <Widget>[
            Container(
              width: 150.0,
              height: 150.0,
              child: ClipRRect(
                  child: imageFile is File
                      ? Image.file(
                          imageFile,
                          fit: BoxFit.cover,
                        )
                      : imageFile == null
                          ? Image.asset(
                              "assets/icons/logo_kecil_unm.png",
                              color: Colors.black,
                            )
                          : FadeInImage.assetNetwork(
                              placeholder: "assets/icons/logo_kecil_unm.png",
                              image: imageFile,
                              fit: BoxFit.cover,
                            )),
              color: Colors.white,
            ),
            Container(
              child: Positioned(
                  bottom: 1,
                  right: 1,
                  child: GestureDetector(
                    onTap: () async {
                      _getFromGallery();
                    },
                    child: Container(
                      height: 40,
                      width: 40,
                      child: Icon(
                        Icons.add_a_photo,
                        color: Colors.white,
                      ),
                      decoration: BoxDecoration(
                          color: kPrimaryColor,
                          borderRadius: BorderRadius.all(Radius.circular(20))),
                    ),
                  )),
            )
          ],
        ),
      ),
    );
  }

  Future _getFromGallery() async {
    final pickedFile = await picker.getImage(source: ImageSource.gallery);

    setState(() {
      if (pickedFile != null) {
        _cropImage(pickedFile.path);
      } else {
        print('No image selected.');
      }
    });
  }

  /// Crop Image
  _cropImage(filePath) async {
    File croppedImage = await ImageCropper.cropImage(
      sourcePath: filePath,
      maxWidth: 600,
      maxHeight: 600,
    );
    if (croppedImage != null) {
      imageFile = croppedImage;
      setState(() {});
    }
  }

  buildTanggalLahirFormField() {
    return TextFormField(
      readOnly: true,
      controller: dateCtl,
      textInputAction: TextInputAction.next,
      keyboardType: TextInputType.number,
      onSaved: (newValue) => dateTime = newValue,
      onTap: () async {
        setDate(context);
      },
      onChanged: (value) {
        if (value.isNotEmpty) {
          removeError(error: "Masukkan Tanggal Lahir Anda");
        }
        return null;
      },
      validator: (value) {
        if (value.isEmpty) {
          addError(error: "Masukkan Tanggal Lahir Anda");
          return "";
        }
        return null;
      },
      decoration: InputDecoration(
        labelText: "Tanggal Lahir",

        hintText: "Tanggal lahir",
        errorStyle: TextStyle(height: 0),

        // If  you are using latest version of flutter then lable text and hint text shown like this
        // if you r using flutter less then 1.20.* then maybe this is not working properly
        floatingLabelBehavior: FloatingLabelBehavior.always,
        suffixIcon: CustomSurffixIcon(icon: Icons.date_range),
      ),
    );
  }


  void setDate(BuildContext context) {
      showModalBottomSheet(
          context: context,
          builder: (_) => Container(
            color: Color.fromARGB(255, 255, 255, 255),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: Get.width,
                  padding: EdgeInsets.all(10),
                  color: kPrimaryColor,
                  child: Text(
                    "Tanggal",
                    textAlign: TextAlign.center,
                    style: StyleText.textBodyPutih16,
                  ),
                ),
                Flexible(
                  child: Container(
                    height: 150,
                    child: CupertinoDatePicker(
                        mode: CupertinoDatePickerMode.date,
                        initialDateTime: DateTime.now(),
                        maximumDate: DateTime.now(),
                        maximumYear: DateTime.now().year,
                        onDateTimeChanged: (val) {
                          setState(() {
                            dateCtl.text = f.format(val).toString();
                          });
                        }),
                  ),
                ),

                // Close the modal
                Padding(
                    padding: EdgeInsets.all(10),
                    child: DefaultButton(
                        text: "Simpan",
                        press: () {
                          return Navigator.of(context).pop();
                        }))
              ],
            ),
          ));
    }

}

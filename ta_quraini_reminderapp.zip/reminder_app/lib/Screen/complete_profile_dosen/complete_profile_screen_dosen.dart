import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:reminder_app/Setup/constants.dart';
import 'package:reminder_app/Setup/size_config.dart';

import 'body.dart';

class CompleteProfileDosenScreen extends StatelessWidget {
  String emailUser = Get.arguments[0] ?? "";
  String passUser = Get.arguments[1] ?? "";
  String statusUser = Get.arguments[2] ?? "";

  static String routeName = "/Screen.complete_profile_dosen";
  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      body: SafeArea(
        child: Container(
          color: kBackgroundGrey,
          height: double.infinity,
          child: Stack(
            children: [
              Body(
                  emailUser: emailUser, passUser: passUser, status: statusUser),
              Padding(
                padding: EdgeInsets.all(getProportionateScreenWidth(10)),
                child: SizedBox(
                  height: getProportionateScreenWidth(40),
                  width: getProportionateScreenWidth(40),
                  child: FlatButton(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(60),
                    ),
                    color: Colors.white,
                    padding: EdgeInsets.zero,
                    onPressed: () => Navigator.pop(context),
                    child: SvgPicture.asset(
                      "assets/icons/Back ICon.svg",
                      height: 15,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

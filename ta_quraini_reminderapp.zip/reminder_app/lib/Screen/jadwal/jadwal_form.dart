import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:reminder_app/Model/ModelDosen.dart';
import 'package:reminder_app/Model/ModelJadwal.dart';
import 'package:reminder_app/Controller/ControllerDsn.dart';
import 'package:reminder_app/Controller/ControllerJadwal.dart';
import 'package:reminder_app/Setup/constants.dart';
import 'package:reminder_app/Setup/size_config.dart';
import 'package:reminder_app/Widget/StyleText.dart';
import 'package:reminder_app/Widget/custom_surfix_icon.dart';
import 'package:reminder_app/Widget/default_button.dart';
import 'package:reminder_app/Widget/form_error.dart';
import 'package:reminder_app/Widget/keyboard.dart';
import 'package:shared_preferences/shared_preferences.dart';

class JadwalForm extends StatefulWidget {
  @override
  _JadwalFormState createState() => _JadwalFormState();
}

class _JadwalFormState extends State<JadwalForm> {
  ControllerDsn controlDsn = Get.put(ControllerDsn());
  final ControllerJadwal jadwaalControl = Get.put(ControllerJadwal());

  var _formKeyJadwal = GlobalKey<FormState>();

  bool loading = true;
  var tittle = "Loading";
  ModelDosen modelDosen;
  List<ModelDosen> listDosen = [];
  var _selectDosen;
  String nimNip;
  var idTokenDosen;

  String stsLoading;

  TextEditingController ctrlJdl = TextEditingController(text: "");
  TextEditingController ctrlPerihal = TextEditingController(text: "");

  final List<String> errors = [];

  void addError({String error}) {
    if (!errors.contains(error))
      setState(() {
        errors.add(error);
      });
  }

  void removeError({String error}) {
    if (errors.contains(error))
      setState(() {
        errors.remove(error);
      });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getDataDosen();
  }

  Future<void> getDataDosen() async {
    SharedPreferences loginCheck = await SharedPreferences.getInstance();

    nimNip = loginCheck.getString(LoginValue.idLogin);

    listDosen = await controlDsn.allDosen();
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          child: FutureBuilder<Object>(
              future: getDataDosen(),
              builder: (context, snapshot) {
                return Form(
                  key: _formKeyJadwal,
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      buildFormDosen(),
                      SizedBox(height: getProportionateScreenHeight(15)),
                      _buildJadwalTitleForm(),
                      SizedBox(height: getProportionateScreenHeight(15)),
                      buildPerihalFormField(),
                      FormError(errors: errors),
                      SizedBox(height: getProportionateScreenHeight(15)),
                      DefaultButton(
                          text: "Tambah Jadwal",
                          press: () async {
                            // Get.toNamed(CompleteProfileScreen.routeName);
                            //
                            loading = true;

                            if (_formKeyJadwal.currentState.validate() &&
                                _selectDosen == null) {
                              addError(error: "Dosen Tidak Boleh Kosong");
                            } else if (_formKeyJadwal.currentState.validate()) {
                              _formKeyJadwal.currentState.save();

                              showLoading();
                              ModelJadwal model = ModelJadwal(
                                idJadwal: DateTime.now()
                                    .millisecondsSinceEpoch
                                    .toString(),
                                judulJadwal: ctrlJdl.text,
                                catatanJadwal: ctrlPerihal.text,
                                idMahasiswaJadwal: nimNip,
                                idDosenJadwal: _selectDosen,
                              );

                              KeyboardUtil.hideKeyboard(context);

                              saveDataJadwal(model, idTokenDosen);

                              //   // if all are valid then go to success screen
                              // }
                            }
                          })
                    ],
                  ),
                );
              }),
        ),
      ],
    );
  }

  TextFormField buildPerihalFormField() {
    return TextFormField(
      maxLines: 6,
      minLines: 3,
      keyboardType: TextInputType.text,
      controller: ctrlPerihal,
      onChanged: (value) {
        if (value.isNotEmpty) {
          removeError(error: kPerihalNullError);
        }
        return null;
      },
      validator: (value) {
        if (value.isEmpty) {
          addError(error: kPerihalNullError);
          return "";
        }
        return null;
      },
      decoration: InputDecoration(
        labelText: "Perihal",
        hintText: "Masukkan Perihal",
        isDense: true,
        alignLabelWithHint: true,
        errorStyle: TextStyle(height: 0),
        floatingLabelBehavior: FloatingLabelBehavior.always,
        suffixIcon: CustomSurffixIcon(
          icon: Icons.assignment_outlined,
        ),
      ),
    );
  }

  TextFormField _buildJadwalTitleForm() {
    return TextFormField(
      keyboardType: TextInputType.text,
      autofocus: false,
      controller: ctrlJdl,
      onChanged: (value) {
        if (value.isNotEmpty) {
          removeError(error: kTitleNullError);
        }
      },
      validator: (value) {
        if (value.isEmpty) {
          addError(error: kTitleNullError);
        }
        return null;
      },
      decoration: InputDecoration(
        labelText: "Judul",
        hintText: "Masukkan Judul",
        isDense: true,
        errorStyle: TextStyle(height: 0),
        floatingLabelBehavior: FloatingLabelBehavior.always,
        suffixIcon: CustomSurffixIcon(
          icon: Icons.assignment_outlined,
        ),
      ),
    );
  }

  DropdownButtonFormField buildFormDosen() {
    return DropdownButtonFormField(
      focusColor: kPrimaryColor,
      hint: _selectDosen == null
          ? Text('Pilih Dosen')
          : Text(
              _selectDosen,
              style: TextStyle(color: Colors.blue),
            ),
      isExpanded: true,
      // iconSize: 30.0, // Not necessary for Option 1
      value: _selectDosen,
      onChanged: (newValue) {
        setState(() {
          removeError(error: "Dosen Tidak Boleh Kosong");
          _selectDosen = newValue;
        });
      },
      items: listDosen.map((location) {
        return DropdownMenuItem(
          child: RichText(
            text: TextSpan(
              style: StyleText.textBodyHitam16.copyWith(fontFamily: "Muli"),
              children: [
                TextSpan(text: location.namaDsn),
                TextSpan(
                    text: " (" + location.nipDsn + ")",
                    style: StyleText.textSubBodyHitam14
                        .copyWith(color: Colors.grey)),
              ],
            ),
          ),
          onTap: () {
            setState(() {
              return idTokenDosen = location.tokenDsn;
            });
          },
          value: location.nipDsn,
        );
      }).toList(growable: false),
    );
  }

  Future<void> saveDataJadwal(ModelJadwal model, String idTokenDosen) async {
    String sts = await jadwaalControl.addJadwal(model, idTokenDosen);

    if (sts.isNotEmpty) {
      Navigator.of(context).pop();
      setState(() {
        loading = false;
        stsLoading = sts;
        ctrlJdl = TextEditingController(text: "");
        ctrlPerihal = TextEditingController(text: "");
      });

      //  await notificationPlugin.showNotification();
      // await NotifikasiSetup()
      //     .sendNotif(model.judulJadwal, model.catatanJadwal, idTokenDosen);
    }
  }

  showLoading() {
    Get.dialog(
      AlertDialog(
        title: Text('Perbaruhi Data'),
        content: new Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            stsLoading == null
                ? new CircularProgressIndicator()
                : Icon(
                    Icons.check,
                    color: Colors.green,
                  ),
            SizedBox(width: 10),
            new Text(
              stsLoading == null ? "Loading " : stsLoading,
              style: StyleText.textBiasaHitam14,
            ),
          ],
        ),
      ),
    );
    if (Get.isDialogOpen && stsLoading != null) {
      setState(() {
        stsLoading = null;
      });
      Future.delayed(Duration(seconds: 1), () {
        Navigator.pop(context);
      });
    }
  }
}

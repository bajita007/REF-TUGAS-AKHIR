import 'package:flutter/material.dart';
import 'package:reminder_app/Screen/jadwal/jadwal_form.dart';
import 'package:reminder_app/Setup/constants.dart';
import 'package:reminder_app/Setup/size_config.dart';

class JadwalScreen extends StatefulWidget {
  static String routeName = "/Screen.jadwal";

  @override
  _JadwalScreenState createState() => _JadwalScreenState();
}

class _JadwalScreenState extends State<JadwalScreen> {
  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Container(
        color: kBackgroundGrey,
        child: SizedBox(
            width: SizeConfig.screenWidth,
            child: Padding(
              padding: EdgeInsets.symmetric(
                  horizontal: getProportionateScreenWidth(20)),
              child: ScrollConfiguration(
                behavior: new ScrollBehavior()
                  ..buildViewportChrome(context, null, AxisDirection.down),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      SizedBox(height: SizeConfig.screenHeight * 0.04),
                      JadwalForm(),
                      SizedBox(height: getProportionateScreenHeight(20)),
                    ],
                  ),
                ),
              ),
            )));
  }
}

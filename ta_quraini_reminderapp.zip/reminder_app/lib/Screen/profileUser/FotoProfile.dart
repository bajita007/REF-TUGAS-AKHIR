import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:reminder_app/Setup/constants.dart';
import 'package:reminder_app/Setup/size_config.dart';
import 'package:reminder_app/Widget/StyleText.dart';

class FotoProfile extends StatefulWidget {
  FotoProfile(
    this.userRole,
    this.visible,
    this.idUser,
    this.imageFile,
    this.foto, {
    Key key,
  }) : super(key: key);

  String userRole;
  String idUser;
  bool visible;
  var foto;
  var imageFile;

  @override
  _FotoProfileState createState() => _FotoProfileState();
}

enum AppState {
  free,
  picked,
  cropped,
}

class _FotoProfileState extends State<FotoProfile> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    widget.imageFile = widget.foto ?? null;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        height: 220,
        width: SizeConfig.screenWidth,
        child: Padding(
          padding: const EdgeInsets.only(top: 45, bottom: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Flexible(
                child: Stack(children: [
                  Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15.0),
                    ),
                    elevation: 0.0,
                    clipBehavior: Clip.antiAlias,
                    shadowColor: null,
                    color: Colors.white,
                    child: Stack(
                      children: <Widget>[
                        Container(
                          width: 125.0,
                          height: 125.0,
                          child: ClipRRect(
                              child: widget.imageFile is File
                                  ? Image.file(
                                      widget.imageFile,
                                      fit: BoxFit.cover,
                                    )
                                  : widget.imageFile == null
                                      ? Image.asset(
                                          "assets/icons/logo_kecil_unm.png",
                                          color: Colors.black,
                                        )
                                      : FadeInImage.assetNetwork(
                                          placeholder:
                                              "assets/icons/logo_kecil_unm.png",
                                          image: widget.imageFile,
                                          fit: BoxFit.cover,
                                        )),
                          color: kPrimaryColor.withOpacity(0.25),
                        ),
                        Visibility(
                          visible: widget.visible,
                          child: Positioned(
                              bottom: 1,
                              right: 1,
                              child: Container(
                                height: 32,
                                width: 32,
                                child: GestureDetector(
                                  onTap: () {
                                    _getFromGallery();
                                  },
                                  child: Icon(
                                    Icons.add_a_photo,
                                    color: kPrimaryColor,
                                  ),
                                ),
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(15))),
                              )),
                        )
                      ],
                    ),
                  ),
                ]),
              ),
              Text(
                (widget.userRole == "Dosen")
                    ? "Nip : ${widget.idUser.toString()}"
                    : "Nim : ${widget.idUser.toString()}",
                style: StyleText.textSubBodyPutih14,
              ),
            ],
          ),
        ));
  }

  _getFromGallery() async {
    PickedFile pickedFile = await ImagePicker().getImage(
      source: ImageSource.gallery,
      maxWidth: 600,
      maxHeight: 600,
    );
    _cropImage(pickedFile.path);
  }

  /// Crop Image
  _cropImage(filePath) async {
    File croppedImage = await ImageCropper.cropImage(
      sourcePath: filePath,
      maxWidth: 600,
      maxHeight: 600,
    );
    if (croppedImage != null) {
      setState(() {
        widget.imageFile = croppedImage;
        widget.foto = croppedImage;
      });
    }
  }
}

import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:reminder_app/Model/EditDataModel.dart';
import 'package:reminder_app/Model/ModelDosen.dart';
import 'package:reminder_app/Model/ModelMhs.dart';
import 'package:reminder_app/Controller/ControllerDsn.dart';
import 'package:reminder_app/Controller/ControllerMhs.dart';
import 'package:reminder_app/Setup/constants.dart';
import 'package:reminder_app/Setup/size_config.dart';
import 'package:reminder_app/Widget/DefaultOnback.dart';
import 'package:reminder_app/Widget/StyleText.dart';
import 'package:reminder_app/Widget/custom_surfix_icon.dart';
import 'package:reminder_app/Widget/default_button.dart';
import 'package:reminder_app/Widget/form_error.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ProfileScreen extends StatefulWidget {
  static String routeName = "/Screen.profile";

  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  var controllerDsn = Get.put(ControllerDsn(), permanent: true);
  var controllerMhs = Get.put(ControllerMhs());
  List<DataDialog> dataDialogList = [];
  String idUser;
  String userRole = "";
  String passDsn;
  String namaUser;
  var boolLoading;
  bool onClick = false;
  ModelMhs modelMhs = ModelMhs();
  bool isLoading;
  ModelDosen modelDosen = ModelDosen();
  final _formKey = GlobalKey<FormState>();
  final List<String> errors = [];
  var foto;
  var cstmnBackval = false;

  var f = new DateFormat("EEEE, d MMMM yyyy", "id_ID");

  TextEditingController saveNipNim;
  TextEditingController saveNama;
  TextEditingController saveAlamat;
  TextEditingController saveNo;
  TextEditingController saveEmail;
  TextEditingController saveTtl;
  TextEditingController saveAngk;
  TextEditingController saveJur;

  Future<void> dataUser;

  @override
  void initState() {
    isLoading = true;
    dataUser = checkLogin();
    printInfo(info: userRole.toString());
    super.initState();
  }

  Future<void> checkLogin() async {
    SharedPreferences loginCheck = await SharedPreferences.getInstance();
    userRole = loginCheck.getString(LoginValue.idRole);
    idUser = loginCheck.getString(LoginValue.idLogin);
    passDsn = loginCheck.getString(LoginValue.passLogin);

    printInfo(info: userRole.toString() + "CHECC");

    if (userRole.contains("Dosen")) {
      modelDosen = await controllerDsn.getDsn(
          user: idUser,
          pass: passDsn,
          saveLocal: false,
          idOnly: false,
          updateData: false);
    } else {
      modelMhs = await controllerMhs.getMhs(
          user: idUser,
          pass: passDsn,
          saveLocal: false,
          idOnly: false,
          updateData: false);
    }
    setState(() {});
    return addDataUser();
  }

  addDataUser() {
    dataDialogList = [
      DataDialog(
        obscureText: true,
        onSaved: saveEmail = controller(
            saveEmail,
            userRole.contains("Dosen")
                ? modelDosen.emailDsn ?? ""
                : modelMhs.emailMhs ?? ""),
        editTable: false,
        costumSuffix: CustomSurffixIcon(svgIcon: "assets/icons/User.svg"),
        labelText: "Email",
      ),
      DataDialog(
        obscureText: true,
        editTable: true,
        onSaved: saveNama = controller(
            saveNama,
            userRole.contains("Dosen")
                ? modelDosen.namaDsn ?? ""
                : modelMhs.namaMhs ?? ""),
        typeKeyboard: "Text",
        costumSuffix: CustomSurffixIcon(svgIcon: "assets/icons/User.svg"),
        labelText: "Nama",
      ),
      DataDialog(
        visible: false,
        obscureText: false,
        editTable: true,
        onSaved: saveJur = controller(
            saveJur, userRole.contains("Dosen") ? "" : modelMhs.jurMhs ?? ""),
        typeKeyboard: "Text",
        costumSuffix: CustomSurffixIcon(svgIcon: "assets/icons/User.svg"),
        labelText: "Jurusan",
      ),
      DataDialog(
        visible: false,
        obscureText: false,
        editTable: true,
        onSaved: saveAngk = controller(
            saveAngk, userRole.contains("Dosen") ? "" : modelMhs.angMhs ?? ""),
        typeKeyboard: "Nomor",
        costumSuffix: CustomSurffixIcon(svgIcon: "assets/icons/User.svg"),
        labelText: "Angkatan / Tahun Masuk",
      ),
      DataDialog(
        obscureText: true,
        editTable: true,
        onSaved: saveTtl = controller(
            saveTtl,
            userRole.contains("Dosen")
                ? modelDosen.ttlDsn ?? ""
                : modelMhs.ttlMhs ?? ""),
        costumSuffix: CustomSurffixIcon(svgIcon: "assets/icons/User.svg"),
        labelText: "Tanggal Lahir",
      ),
      DataDialog(
        obscureText: true,
        editTable: true,
        onSaved: saveNo = controller(
            saveNo,
            userRole.contains("Dosen")
                ? modelDosen.noDsn ?? ""
                : modelMhs.noMhs ?? ""),
        typeKeyboard: "Telpon",
        costumSuffix: CustomSurffixIcon(svgIcon: "assets/icons/User.svg"),
        labelText: "No Telpon / No Hp",
      ),
      DataDialog(
        obscureText: true,
        editTable: true,
        onSaved: saveAlamat = controller(
            saveAlamat,
            userRole.contains("Dosen")
                ? modelDosen.alamatDsn ?? ""
                : modelMhs.alamatMhs ?? ""),
        costumSuffix: CustomSurffixIcon(svgIcon: "assets/icons/User.svg"),
        labelText: "Alamat",
        line: 3,
      ),
    ];
    return dataDialogList;
  }

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);

    return Scaffold(
        body: AnnotatedRegion<SystemUiOverlayStyle>(
            value: SystemUiOverlayStyle.light
                .copyWith(statusBarColor: Theme.of(context).primaryColor),
            child: SafeArea(
              child: FutureBuilder(
                future: dataUser,
                builder: (context, snapshot) {
                  return Container(
                      color: kBackgroundGrey,
                      height: double.infinity,
                      child: (idUser != null)
                          ? BodyProfileUser()
                          : Stack(children: [
                              Container(
                                  height: 240,
                                  decoration: BoxDecoration(
                                    color: kPrimaryColor,
                                    borderRadius: BorderRadius.only(
                                      bottomLeft: Radius.circular(30),
                                      bottomRight: Radius.circular(30),
                                    ),
                                  )),
                              //  FotoProfile(userRole, onClick, idUser),
                              setLoading()
                            ]));
                }
              ),
            )));
  }

  Widget BodyProfileUser() {
    return Column(
      children: [
        HeaderProfile(),
        (dataDialogList.length == 0) ? setLoading() : SizedBox(),
        FormProfile(),
      ],
    );
  }

  Widget setLoading() {
    return Visibility(
      visible: isLoading,
      child: Center(
        child: CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(kPrimaryColor)),
      ),
    );
  }

  Widget HeaderProfile() {
    return Stack(
      children: [
        Container(
            height: 240,
            decoration: BoxDecoration(
              color: kPrimaryColor,
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(30),
                bottomRight: Radius.circular(30),
              ),
            )),
        FotoProfile(userRole, onClick, idUser),
        DefaultOnBackButton(
          status: "profile",
          colors: Colors.white,
          colorsIcon: kPrimaryColor,
        ),
        Container(
          height: 50,
          margin: EdgeInsets.only(
              top: 215.0,
              left: (onClick) ? 40 : 60,
              right: (onClick) ? 40 : 60),
          padding: EdgeInsets.only(left: 20),
          decoration: BoxDecoration(
            color: Colors.yellow,
            borderRadius: BorderRadius.all(Radius.circular(30)),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            mainAxisSize: MainAxisSize.max,
            children: [
              Text(
                userRole.toString(),
                style: StyleText.textBodyHitam16,
              ),
              Visibility(
                visible: (dataDialogList.length > 0),
                child: GestureDetector(
                  onTap: () {
                    setState(() {
                      if (!onClick) {
                        onClick = true;
                      } else {
                        if (_formKey.currentState.validate() == true) {
                          print(foto.toString() + "FILE");
                          print("Validasi" +
                              _formKey.currentState.validate().toString());
                          _formKey.currentState.save();
                          onClick = false;
                          boolLoading = true;
                          showLoading();

                          if (userRole.contains("Dosen")) {
                            modelDosen.nipDsn = modelDosen.nipDsn;
                            modelDosen.namaDsn = saveNama.text.toString();
                            modelDosen.alamatDsn = saveAlamat.text;
                            modelDosen.emailDsn = saveEmail.text;
                            modelDosen.noDsn = saveNo.text;
                            modelDosen.ttlDsn = saveTtl.text;
                          } else {
                            modelMhs.nimMhs = modelMhs.nimMhs;
                            modelMhs.namaMhs = saveNama.text;
                            modelMhs.alamatMhs = saveAlamat.text;
                            modelMhs.emailMhs = saveEmail.text;
                            modelMhs.noMhs = saveNo.text;
                            modelMhs.angMhs = saveAngk.text;
                            modelMhs.ttlMhs = saveTtl.text;
                            modelMhs.jurMhs = saveJur.text;
                          }

                          updateData();
                          // f all
                        }
                      }
                    });
                  },
                  child: Container(
                    height: 50,
                    padding: EdgeInsets.symmetric(horizontal: 20),
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.all(Radius.circular(30)),
                    ),
                    child: Row(
                      children: [
                        Text(
                          (onClick) ? "Simpan" : "Edit",
                          style: StyleText.textBodyPutih16,
                        ),
                        SizedBox(width: 20),
                        Padding(
                          padding:
                              EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                          child: Icon(
                            (onClick) ? Icons.save : Icons.edit,
                            size: 20,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget FormProfile() {
    return Expanded(
      child: Card(
        margin: EdgeInsets.fromLTRB(20, 20, 20, 20),
        color: Color.fromRGBO(225, 236, 0, 0),
        elevation: 0,
        child: SingleChildScrollView(
          physics: BouncingScrollPhysics(),
          child: Column(
            children: <Widget>[
              Form(
                key: _formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: dataDialogList
                      .map((data) => Column(
                            children: <Widget>[
                              Visibility(
                                  visible: userRole.contains("Dosen")
                                      ? data.obscureText
                                      : true,
                                  child: Padding(
                                    padding:
                                        const EdgeInsets.only(bottom: 10.0),
                                    child: TextFormField(
                                      onTap: () {
                                        if (data.labelText == "Tanggal Lahir" &&
                                            onClick == true &&
                                            data.editTable == true)
                                          setDate(context, data.onSaved);
                                      },
                                      keyboardType:
                                          (data.typeKeyboard == "Telpon")
                                              ? TextInputType.phone
                                              : (data.typeKeyboard == "Nomor")
                                                  ? TextInputType.number
                                                  : TextInputType.text,
                                      readOnly: (onClick == true &&
                                              data.editTable == true &&
                                              data.labelText != "Tanggal Lahir")
                                          ? false
                                          : true,
                                      minLines: data.line ?? 1,
                                      maxLines: 5,
                                      // textInputAction: TextInputAction.next,
                                      controller: data.onSaved,
                                      onChanged: (value) {
                                        if (value.isNotEmpty) {
                                          removeError(
                                              error:
                                                  "${data.labelText} Tidak Boleh Kosong");
                                        }
                                        return null;
                                      },
                                      validator: (value) {
                                        if (value.isEmpty) {
                                          addError(
                                              error:
                                                  "${data.labelText} Tidak Boleh Kosong");
                                          return "";
                                        }

                                        return null;
                                      },
                                      decoration: InputDecoration(
                                        focusedBorder: (onClick == true &&
                                                data.editTable == true)
                                            ? null
                                            : OutlineInputBorder(
                                                borderRadius:
                                                    BorderRadius.circular(10),
                                                borderSide: const BorderSide(
                                                    color: Colors.white,
                                                    width: 2.0),
                                                gapPadding: 10,
                                              ),
                                        disabledBorder: null,
                                        enabledBorder: null,
                                        border: null,
                                        labelText: data.labelText,
                                        hintText: data.labelText,
                                        errorStyle: TextStyle(height: 0),
                                        floatingLabelBehavior:
                                            FloatingLabelBehavior.always,
                                      ),
                                    ),
                                  )),
                            ],
                          ))
                      .toList(),
                ),
              ),
              FormError(errors: errors),
            ],
          ),
        ),
      ),
    );
  }

  void addError({String error}) {
    if (!errors.contains(error))
      setState(() {
        errors.add(error);
      });
  }

  void removeError({String error}) {
    if (errors.contains(error))
      setState(() {
        errors.remove(error);
      });
  }

  updateData() async {
    printInfo(info: userRole.toString());
    if (userRole.contains("Dosen")) {
      print("OKE F");
      printInfo(info: userRole.toString() + "OKEE DOSEN");

      await controllerDsn.updateDosen(
          modelDosen: modelDosen, file: foto, saveLocal: true);
    } else {
      await controllerMhs.updateMhs(
          modelDosen: modelMhs, file: foto, saveLocal: true);
      print("OKE");
      printInfo(info: userRole.toString() + "OKEE MHS");
    }

    if (Get.isSnackbarOpen == true) {
      print("CLosee");
      Future.delayed(Duration(seconds: 3), () {
        Navigator.pop(context);
      });
    }
  }

  TextEditingController controller(
      TextEditingController control, String value) {
    control = TextEditingController(text: value ?? "");
    control.selection = TextSelection.fromPosition(
      TextPosition(offset: value.length),
    );
    return control;
  }

  showLoading() {
    if (boolLoading) {
      Get.dialog(
        AlertDialog(
          title: Text('Perbaruhi Data'),
          content: new Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              new CircularProgressIndicator(),
              SizedBox(width: 10),
              new Text("Loading "),
            ],
          ),
        ),
      );
    }
  }

  FotoProfile(String userRole, bool onClick, String idUser) {
    foto = userRole.toString().toUpperCase().contains("DOSEN")
        ? modelDosen.fotoDsn
        : modelMhs.fotoMhs;
    return Container(
        height: 220,
        width: SizeConfig.screenWidth,
        child: Padding(
          padding: const EdgeInsets.only(top: 45, bottom: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Flexible(
                child: Stack(children: [
                  Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15.0),
                    ),
                    elevation: 0.0,
                    clipBehavior: Clip.antiAlias,
                    shadowColor: null,
                    color: Colors.white,
                    child: Stack(
                      children: <Widget>[
                        Container(
                          width: 125.0,
                          height: 125.0,
                          child: ClipRRect(
                              child: foto is File
                                  ? Image.file(
                                      foto,
                                      fit: BoxFit.cover,
                                    )
                                  : foto == null
                                      ? Image.asset(
                                          "assets/icons/logo_kecil_unm.png",
                                          color: Colors.black,
                                        )
                                      : FadeInImage.assetNetwork(
                                          placeholder:
                                              "assets/icons/logo_kecil_unm.png",
                                          image: foto,
                                          fit: BoxFit.cover,
                                        )),
                          color: kPrimaryColor.withOpacity(0.25),
                        ),
                        Visibility(
                          visible: onClick,
                          child: Positioned(
                              bottom: 1,
                              right: 1,
                              child: Container(
                                height: 32,
                                width: 32,
                                child: GestureDetector(
                                  onTap: () {
                                    _getFromGallery();
                                  },
                                  child: Icon(
                                    Icons.add_a_photo,
                                    color: kPrimaryColor,
                                  ),
                                ),
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(15))),
                              )),
                        )
                      ],
                    ),
                  ),
                ]),
              ),
              Text(
                (userRole == "Dosen")
                    ? "Nip : ${idUser.toString()}"
                    : "Nim : ${idUser.toString()}",
                style: StyleText.textSubBodyPutih14,
              ),
            ],
          ),
        ));
  }

  _getFromGallery() async {
    PickedFile pickedFile = await ImagePicker().getImage(
      source: ImageSource.gallery,
      maxWidth: 600,
      maxHeight: 600,
    );
    _cropImage(pickedFile.path);
  }

  /// Crop Image
  _cropImage(filePath) async {
    File croppedImage = await ImageCropper.cropImage(
      sourcePath: filePath,
      maxWidth: 600,
      maxHeight: 600,
    );
    if (croppedImage != null) {
      setState(() {
        foto = croppedImage;
      });
    }
  }

  void setDate(BuildContext context, TextEditingController onSaved) {
    showModalBottomSheet(
        context: context,
        builder: (_) => Container(
              color: Color.fromARGB(255, 255, 255, 255),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: Get.width,
                    padding: EdgeInsets.all(10),
                    color: kPrimaryColor,
                    child: Text(
                      "Tanggal",
                      textAlign: TextAlign.center,
                      style: StyleText.textBodyPutih16,
                    ),
                  ),
                  Flexible(
                    child: Container(
                      height: 150,
                      child: CupertinoDatePicker(
                          mode: CupertinoDatePickerMode.date,
                          initialDateTime: DateTime.now(),
                          maximumDate: DateTime.now(),
                          maximumYear: DateTime.now().year,
                          onDateTimeChanged: (val) {
                            setState(() {
                              saveTtl.text = f.format(val).toString();
                            });
                          }),
                    ),
                  ),

                  // Close the modal
                  Padding(
                      padding: EdgeInsets.all(10),
                      child: DefaultButton(
                          text: "Simpan",
                          press: () {
                            return Navigator.of(context).pop();
                          }))
                ],
              ),
            ));
  }
}

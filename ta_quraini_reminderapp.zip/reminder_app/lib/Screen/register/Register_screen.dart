import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:reminder_app/Screen/Login/Login_screen.dart';
import 'package:reminder_app/Screen/register/sign_up_form.dart';
import 'package:reminder_app/Setup/constants.dart';
import 'package:reminder_app/Setup/size_config.dart';
import 'package:reminder_app/Widget/DefaultOnback.dart';
import 'package:reminder_app/Widget/StyleText.dart';

class ScreenRegister extends StatefulWidget {
  static String routeName = "/Screen.register";

  @override
  _ScreenRegisterState createState() => _ScreenRegisterState();
}

class _ScreenRegisterState extends State<ScreenRegister> {
  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      body: Container(
        height: double.infinity,
        color: kBackgroundGrey,
        child: SafeArea(
          child: SizedBox(
            width: double.infinity,
            child: Stack(
              children: [
                Padding(
                  padding: EdgeInsets.symmetric(
                      horizontal: getProportionateScreenWidth(20)),
                  child: SingleChildScrollView(
                      physics: BouncingScrollPhysics(),
                      child: Column(
                        children: [
                          SizedBox(
                              height: SizeConfig.screenHeight * 0.04), // 4%
                          Text("Daftar Akun", style: headingStyle),
                          SizedBox(height: SizeConfig.screenHeight * 0.02),
                          logo(75),
                          SizedBox(height: SizeConfig.screenHeight * 0.02),
                          SignUpForm(),
                          SizedBox(height: getProportionateScreenHeight(10)),
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                'Anda Sudah Memiliki Akun.?',
                                textAlign: TextAlign.center,
                                style: Theme.of(context).textTheme.caption,
                              ),
                              GestureDetector(
                                child: Text(
                                  ' Masuk',
                                  textAlign: TextAlign.center,
                                  style: StyleText.textSubBodyPutih14
                                      .copyWith(color: kPrimaryColor),
                                ),
                                onTap: () =>
                                    Get.offNamed(LoginScreen.routeName),
                              ),
                            ],
                          )
                        ],
                      )),
                ),
                DefaultOnBackButton(
                  status: null,
                  colors: kPrimaryColor,
                  colorsIcon: Colors.white,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/route_manager.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:reminder_app/Screen/complete_profile/complete_profile_screen.dart';
import 'package:reminder_app/Screen/complete_profile_dosen/complete_profile_screen_dosen.dart';
import 'package:reminder_app/Setup/constants.dart';
import 'package:reminder_app/Setup/size_config.dart';
import 'package:reminder_app/Widget/custom_surfix_icon.dart';
import 'package:reminder_app/Widget/default_button.dart';
import 'package:reminder_app/Widget/form_error.dart';

class SignUpForm extends StatefulWidget {
  @override
  _SignUpFormState createState() => _SignUpFormState();
}

class _SignUpFormState extends State<SignUpForm> {
  final _formKey = GlobalKey<FormState>();
  String email;
  String password;
  String conform_password;
  int id = 1;
  String radioButtonItem = 'Mahasiswa';
  bool remember;

  final List<String> errors = [];

  void addError({String error}) {
    if (!errors.contains(error))
      setState(() {
        errors.add(error);
      });
  }

  void removeError({String error}) {
    if (errors.contains(error))
      setState(() {
        errors.remove(error);
      });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    remember = false;
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          buildEmailFormField(),
          SizedBox(height: getProportionateScreenHeight(15)),
          buildPasswordFormField(),
          SizedBox(height: getProportionateScreenHeight(15)),
          buildConformPassFormField(),
          SizedBox(height: getProportionateScreenHeight(15)),
          buildRadioButton(),
          buildShowPass(),
          FormError(errors: errors),
          SizedBox(height: getProportionateScreenHeight(15)),
          DefaultButton(
            text: "Selanjutnya",
            press: () async {
              await Permission.storage.request();

              var status = await Permission.storage.status;

              if (status.isGranted) {
                if (_formKey.currentState.validate()) {
                  _formKey.currentState.save();
                  if (radioButtonItem == "Dosen") {
                    Get.toNamed(CompleteProfileDosenScreen.routeName,
                        arguments: [email, password, radioButtonItem]);
                  } else {
                    Get.toNamed(CompleteProfileScreen.routeName,
                        arguments: [email, password, radioButtonItem]);
                    // if all are valid then go to success screen
                  }
                }
              }else{
                await Permission.storage.request();

              }
            },
          ),
        ],
      ),
    );
  }

  TextFormField buildConformPassFormField() {
    return TextFormField(
      textInputAction: TextInputAction.done,
      obscureText: !remember,
      onSaved: (newValue) => conform_password = newValue,
      onChanged: (value) {
        if (value.isNotEmpty) {
          removeError(error: kPassNullError);
        } else if (value.isNotEmpty && password == conform_password) {
          removeError(error: kMatchPassError);
        }
        conform_password = value;
      },
      validator: (value) {
        if (value.isEmpty) {
          addError(error: kPassNullError);
          return "";
        } else if ((password != value)) {
          addError(error: kMatchPassError);
          return "";
        }
        return null;
      },
      decoration: InputDecoration(
        labelText: "Komfirmasi Kata Sandi",
        hintText: "Masukkan Ulang Kata Sandi",
        errorStyle: TextStyle(height: 0),
        floatingLabelBehavior: FloatingLabelBehavior.always,
        suffixIcon: CustomSurffixIcon(svgIcon: "assets/icons/Lock.svg"),
      ),
    );
  }

  TextFormField buildPasswordFormField() {
    return TextFormField(
      textInputAction: TextInputAction.next,
      obscureText: !remember,
      onSaved: (newValue) => password = newValue,
      onChanged: (value) {
        if (value.isNotEmpty) {
          removeError(error: kPassNullError);
        } else if (value.length >= 6) {
          removeError(error: kShortPassError);
        }
        password = value;
      },
      validator: (value) {
        if (value.isEmpty) {
          addError(error: kPassNullError);
          return "";
        } else if (value.length < 6) {
          addError(error: kShortPassError);
          return "";
        }
        return null;
      },
      decoration: InputDecoration(
        labelText: "Kata Sandi",
        hintText: "Masukkan kata Sandi",
        // If  you are using latest version of flutter then lable text and hint text shown like this
        // if you r using flutter less then 1.20.* then maybe this is not working properly
        floatingLabelBehavior: FloatingLabelBehavior.always,
        errorStyle: TextStyle(height: 0),
        suffixIcon: CustomSurffixIcon(svgIcon: "assets/icons/Lock.svg"),
      ),
    );
  }

  TextFormField buildEmailFormField() {
    return TextFormField(
      keyboardType: TextInputType.emailAddress,
      textInputAction: TextInputAction.next,
      onSaved: (newValue) => email = newValue,
      onChanged: (value) {
        if (value.isNotEmpty) {
          removeError(error: kEmailNullError);
        } else if (emailValidatorRegExp.hasMatch(value)) {
          removeError(error: kInvalidEmailError);
        }
        return null;
      },
      validator: (value) {
        if (value.isEmpty) {
          addError(error: kEmailNullError);
          return "";
        } else if (!emailValidatorRegExp.hasMatch(value)) {
          addError(error: kInvalidEmailError);
          return "";
        }
        return null;
      },
      decoration: InputDecoration(
        labelText: "Email",
        hintText: "Masukkan Email",
        errorStyle: TextStyle(height: 0),

        // If  you are using latest version of flutter then lable text and hint text shown like this
        // if you r using flutter less then 1.20.* then maybe this is not working properly
        floatingLabelBehavior: FloatingLabelBehavior.always,
        suffixIcon: CustomSurffixIcon(svgIcon: "assets/icons/Mail.svg"),
      ),
    );
  }

  CheckboxListTile buildShowPass() {
    return CheckboxListTile(
        value: remember,
        contentPadding: EdgeInsets.all(0),
        controlAffinity: ListTileControlAffinity.leading,
        title: Text("Tampilkan Kata Sandi"),
        activeColor: kPrimaryColor,
        onChanged: (bool newValue) {
          setState(() {
            print(newValue);
            remember = newValue;
          });
        });
  }

  buildRadioButton() {
    return Container(
      padding: EdgeInsets.all(10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: Colors.white,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Text(
            'Sebagai :',
          ),
          Radio(
            value: 1,
            groupValue: id,
            activeColor: kPrimaryColor,
            onChanged: (val) {
              setState(() {
                radioButtonItem = 'Mahasiswa';
                id = 1;
                print(radioButtonItem);
              });
            },
          ),
          Text(
            'Mahasiswa',
            style: TextStyle(color: (id == 1) ? kPrimaryColor : kTextColor),
          ),
          Radio(
            value: 2,
            groupValue: id,
            activeColor: kPrimaryColor,
            onChanged: (val) {
              setState(() {
                radioButtonItem = 'Dosen';
                id = 2;
                print(radioButtonItem);
              });
            },
          ),
          Text(
            'Dosen',
            style: TextStyle(color: (id == 2) ? kPrimaryColor : kTextColor),
          ),
        ],
      ),
    );
  }


}

import 'package:flutter/material.dart';
import 'package:reminder_app/Setup/size_config.dart';

const kPrimaryColor = Colors.deepOrange;

const kBackgroundGrey = Color.fromRGBO(225, 236, 244, 100);

const kPrimaryGradientColor = LinearGradient(
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
  colors: [Colors.orange, Colors.deepOrange],
);
const kSecondaGradientColor = LinearGradient(
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
  colors: [Colors.orange, Colors.deepOrange],
);
const kBgBlack = LinearGradient(
  begin: Alignment.bottomCenter,
  end: Alignment.topCenter,
  colors: [Colors.black, Color.fromRGBO(0, 0, 0, 0)],
);
const kSecondaryColor = Color(0xFF979797);
const kTextColor = Color(0xFF757575);

const kAnimationDuration = Duration(milliseconds: 200);

final headingStyle = TextStyle(
  fontSize: getProportionateScreenWidth(28),
  fontWeight: FontWeight.bold,
  color: Colors.black,
  height: 1.5,
);

const defaultDuration = Duration(milliseconds: 250);

// Form Error
final RegExp emailValidatorRegExp =
    RegExp(r"^[a-zA-Z0-9.]+@[a-zA-Z0-9]+\.[a-zA-Z]+");
const String kEmailNullError = "Silahkan Masukkan Email"; // Email
const String kTitleNullError = "Silahkan Masukkan Judul"; //Judul
const String kPerihalNullError = "Silahkan Masukkan Perihal"; //perihal

const String kInvalidEmailError = "Masukkan Email Yang Benar";
const String kPassNullError = "Masukkan Kata Sandi Anda";
const String kShortPassError = "Kata Sandi Terlalu Pendek";
const String kMatchPassError = "Kata Sandi Tidak Sama";
const String kNimNullError = "Masukkan Nim Anda";
const String kNipNullError = "Masukkan Nip Anda";
const String kNamaNullErro = "Masukkan Nama Lengkap Anda";
const String kAddressNullError = "Masukkan Alamat Anda";

//   nipDsn: nip,
//   namaDsn: namaLengkap,
//   alamatDsn: address,
//   tokenDsn: "2fe62547-78ba-4855-9cd4-37322fd739f4",
//   fotoDsn: null,
//   stsDsn: "Dosen",
//   ttlDsn: "12-2-20202",
//   passDsn: passUser,

class LoginValue {
  static const String stsLogin = "stsLogin"; //bool
  static const String idLogin = "idLogin";
  static const String emailLogim = "emailLogin";
  static const String passLogin = "passLogin";
  static const String validasiLogin = "validasiLogin";
  static const String idRole = "idRole";
}

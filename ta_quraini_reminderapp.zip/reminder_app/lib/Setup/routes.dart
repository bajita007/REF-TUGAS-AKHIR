import 'package:flutter/widgets.dart';
import 'package:reminder_app/Screen/Home/HomeScreen.dart';
import 'package:reminder_app/Screen/Konsultasi/konsultasi_screen.dart';
import 'package:reminder_app/Screen/Login/Login_screen.dart';
import 'package:reminder_app/Screen/Pdf/PrintPdfScreen.dart';
import 'package:reminder_app/Screen/SplashScreen.dart';
import 'package:reminder_app/Screen/complete_profile/complete_profile_screen.dart';
import 'package:reminder_app/Screen/complete_profile_dosen/complete_profile_screen_dosen.dart';
import 'package:reminder_app/Screen/jadwal/jadwal_screen.dart';
import 'package:reminder_app/Screen/profileUser/Profile_screen.dart';
import 'package:reminder_app/Screen/register/Register_screen.dart';

// We use name route
// All our routes will be available here
final Map<String, WidgetBuilder> routes = {
  ScreenRegister.routeName: (context) => ScreenRegister(),
  CompleteProfileScreen.routeName: (context) => CompleteProfileScreen(),
  HomePage.routeName: (context) => HomePage(),
  JadwalScreen.routeName: (context) => JadwalScreen(),
  ProfileScreen.routeName: (context) => ProfileScreen(),
  PrintPdfView.routeName: (context) => PrintPdfView(),
  LoginScreen.routeName: (context) => LoginScreen(),
  SplashView.routeName: (context) => SplashView(),
  KonsultasiScreen.routeName: (context) => KonsultasiScreen(),
  CompleteProfileDosenScreen.routeName: (context) =>
      CompleteProfileDosenScreen(),
};

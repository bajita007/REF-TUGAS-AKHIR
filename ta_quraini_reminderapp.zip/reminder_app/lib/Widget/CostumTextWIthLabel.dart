import 'package:flutter/material.dart';

import 'StyleText.dart';

class CostumTextLabel extends StatelessWidget {
  String title;
  String value;
  int lines;
  var styleText;
  CostumTextLabel({this.title, this.value, this.styleText, this.lines});
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.max,
      children: [
        Expanded(
            flex: 1,
            child: Text(
              title ?? "",
              style: (styleText == null)
                  ? StyleText.textSubBodyHitam14
                  : styleText,
              textAlign: TextAlign.start,
              maxLines: lines ?? null,
            )),
        Text(
          " : ",
          style: (styleText == null) ? StyleText.textSubBodyHitam14 : styleText,
        ),
        Expanded(
            flex: 3,
            child: Text(
              value ?? "",
              style: (styleText == null)
                  ? StyleText.textSubBodyHitam14
                  : styleText,
              textAlign: TextAlign.start,
              maxLines: lines ?? null,
            ))
      ],
    );
  }
}

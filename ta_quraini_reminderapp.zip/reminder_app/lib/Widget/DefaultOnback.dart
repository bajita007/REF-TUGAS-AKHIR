import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:reminder_app/Screen/Login/Login_screen.dart';
import 'package:reminder_app/Setup/constants.dart';
import 'package:reminder_app/Setup/size_config.dart';


import 'package:shared_preferences/shared_preferences.dart';

import 'StyleText.dart';

class DefaultOnBackButton extends StatelessWidget {
  String status;
  var colors;
  var colorsIcon;
  DefaultOnBackButton({this.status, this.colors, this.colorsIcon});

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Padding(
      padding: EdgeInsets.all(getProportionateScreenWidth(10)),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisSize: MainAxisSize.max,
        children: [
          SizedBox(
            height: getProportionateScreenWidth(40),
            width: getProportionateScreenWidth(40),
            child: FlatButton(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(60),
              ),
              color: (colors != null) ? colors : kPrimaryColor,
              padding: EdgeInsets.zero,
              onPressed: () => Navigator.pop(context),
              child: SvgPicture.asset(
                "assets/icons/Back ICon.svg",
                height: 15,
                color: (colorsIcon != null) ? colorsIcon : Colors.white,
              ),
            ),
          ),
          Expanded(
            child: Visibility(
              visible: (status == null) ? false : true,
              child: Center(
                child: Padding(
                  padding:
                      EdgeInsets.only(left: getProportionateScreenWidth(40)),
                  child: Text(
                    "Profil",
                    style: StyleText.textSubHeaderPutih20,
                  ),
                ),
              ),
            ),
          ),
          Visibility(
            visible: (status == null) ? false : true,
            child: FlatButton(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(60),
              ),
              color: (colors != null) ? colors : kPrimaryColor,
              padding: EdgeInsets.zero,
              onPressed: () => LogoutAkun(),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    "Keluar",
                    style: StyleText.textBiasaHitam14
                        .copyWith(color: kPrimaryColor),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  SvgPicture.asset(
                    "assets/icons/Log out.svg",
                    height: 15,
                    color: (colorsIcon != null) ? colorsIcon : Colors.white,
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  LogoutAkun() async {
    final pref = await SharedPreferences.getInstance();
    await pref.clear();
    Get.offAllNamed(LoginScreen.routeName);
  }
}

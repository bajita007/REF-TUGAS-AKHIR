import 'package:flutter/material.dart';

abstract class StyleText {
  static const textTebalPutih12 = const TextStyle(
    fontSize: 12.0,
    fontWeight: FontWeight.w600,
    color: Colors.white,
  );
  static const textTebalHitam12 = const TextStyle(
    fontSize: 12.0,
    fontWeight: FontWeight.w600,
    color: Colors.black,
  );

  static const textBiasaPutih12 = const TextStyle(
    fontSize: 12.0,
    fontWeight: FontWeight.w400,
    color: Colors.white,
  );

  static const textBiasaHitam12 = const TextStyle(
    fontSize: 12.0,
    fontWeight: FontWeight.w400,
    color: Colors.black,
  );
  static const textBiasaHitam14 = const TextStyle(
    fontSize: 14.0,
    fontWeight: FontWeight.w400,
    color: Colors.black,
  );
  static const textBodyHitam16 = const TextStyle(
    fontSize: 16.0,
    fontWeight: FontWeight.w400,
    color: Colors.black,
  );
  static const textBodyPutih16 = const TextStyle(
    fontSize: 16.0,
    fontWeight: FontWeight.w800,
    color: Colors.white,
  );

  static const textSubBodyHitam14 = const TextStyle(
    fontSize: 14.0,
    fontWeight: FontWeight.w400,
    color: Colors.black,
  );
  static const textSubBodyPutih14 = const TextStyle(
    fontSize: 14.0,
    fontWeight: FontWeight.w800,
    color: Colors.white,
  );
  static const textSubHeaderPutih20 = const TextStyle(
    fontSize: 20.0,
    fontWeight: FontWeight.w800,
    color: Colors.white,
  );
  static const textSubHeaderHitam20 = const TextStyle(
    fontSize: 20.0,
    fontWeight: FontWeight.w600,
    color: Colors.black,
  );

  static const textHeaderHitam24 = const TextStyle(
    fontSize: 24.0,
    color: Colors.black,
    fontWeight: FontWeight.w800,
  );
  static const textHeaderPutih24 = const TextStyle(
    fontSize: 24.0,
    color: Colors.white,
    fontWeight: FontWeight.w800,
  );
  static const textKecilHitam10 = const TextStyle(
    fontSize: 10.0,
    color: Colors.black,
    fontWeight: FontWeight.w600,
  );
}

Image logo(double ukuran) {
  return Image.asset(
    "assets/icons/unm_logo.png",
    height: ukuran,
    fit: BoxFit.fitWidth,
  );
}

Image logoKecil(double ukuran) {
  return Image.asset(
    "assets/icons/logo_kecil_unm.png",
    height: ukuran,
    fit: BoxFit.fitWidth,
  );
}

Image logoAmsterdamBest(double ukuran) {
  return Image.asset(
    "assets/images/logo.png",
    color: Colors.white.withAlpha(20),
    height: ukuran,
    fit: BoxFit.fitWidth,
  );
}

const String applicationName = "Reminder App";
const Map<int, String> months = const {
  1: "January",
  2: "February",
  3: "March",
  4: "April",
  5: 'May',
  6: "June",
  7: "July",
  8: "August",
  9: "September",
  10: "October",
  11: "November",
  12: "December"
};

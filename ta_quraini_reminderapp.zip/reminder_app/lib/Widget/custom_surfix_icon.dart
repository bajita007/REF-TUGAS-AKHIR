import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:reminder_app/Setup/size_config.dart';

class CustomSurffixIcon extends StatelessWidget {
  CustomSurffixIcon({Key key, this.svgIcon, this.icon, this.size})
      : super(key: key);

  final String svgIcon;
  final IconData icon;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(
        0,
        getProportionateScreenWidth(20),
        getProportionateScreenWidth(20),
        getProportionateScreenWidth(20),
      ),
      child: (icon == null)
          ? SvgPicture.asset(
              svgIcon,
              height: getProportionateScreenWidth((size == null) ? 18 : size),
            )
          : Icon(
              icon,
              size: (size == null) ? 18 : size,
            ),
    );
  }
}

// import 'dart:async';
//
// import 'package:flutter/material.dart';
// import 'package:onesignal_flutter/onesignal_flutter.dart';
//
// Future<void> main() async {
//   runApp(MessagingExampleApp());
//   OneSignal.shared.setLogLevel(OSLogLevel.verbose, OSLogLevel.none);
//
//   OneSignal.shared.init(
//     "2c6888ce-c4f6-43c3-a1ae-675f9c1f1827",
//   );
//   OneSignal.shared
//       .setInFocusDisplayType(OSNotificationDisplayType.notification);
//   OneSignal.shared.setEmail(email: "07adjie@gmail.com");
//   OneSignal.shared.setSubscription(true);
//   var status = await OneSignal.shared.getPermissionSubscriptionState();
//   print(status.emailSubscriptionStatus.emailUserId);
//   print(status.emailSubscriptionStatus.emailAddress);
//
//   await OneSignal.shared
//       .promptUserForPushNotificationPermission(fallbackToSettings: true);
// }
//
// /// Entry point for the example application.
// class MessagingExampleApp extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Messaging Example App',
//       theme: ThemeData.dark(),
//       routes: {
//         '/': (context) => Application(),
//       },
//     );
//   }
// }
//
// // Crude counter to make messages unique
//
// /// Renders the example application.
// class Application extends StatefulWidget {
//   @override
//   State<StatefulWidget> createState() => _Application();
// }
//
// class _Application extends State<Application> {
//   String _token;
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Cloud Messaging'),
//         actions: <Widget>[
//           PopupMenuButton(
//             itemBuilder: (BuildContext context) {
//               return [
//                 const PopupMenuItem(
//                   value: 'subscribe',
//                   child: Text('Subscribe to topic'),
//                 ),
//                 const PopupMenuItem(
//                   value: 'unsubscribe',
//                   child: Text('Unsubscribe to topic'),
//                 ),
//                 const PopupMenuItem(
//                   value: 'get_apns_token',
//                   child: Text('Get APNs token (Apple only)'),
//                 ),
//               ];
//             },
//           ),
//         ],
//       ),
//       floatingActionButton: FloatingActionButton(
//         onPressed: setButton,
//       ),
//     );
//   }
//
//   Future<void> setButton() async {
//     var status = await OneSignal.shared.getPermissionSubscriptionState();
//
//     var playerId = status.subscriptionStatus.userId;
//     var playerId2 = status.emailSubscriptionStatus.emailUserId;
//     var playerId3 = status.emailSubscriptionStatus.emailAddress;
//     print("ID :" + playerId);
//     print("ID2 :" + playerId2);
//     print("ID3 :" + playerId3);
//
//     return await OneSignal.shared.postNotification(OSCreateNotification(
//         playerIds: [playerId],
//         content: "this is a test from WKWKWKW",
//         heading: "Test Notification",
//         buttons: [
//           OSActionButton(text: "test1", id: "id1"),
//           OSActionButton(text: "test2", id: "id2")
//         ]));
//   }
// }
